/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: estateos_prod
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Account` (
  `id` varchar(191) NOT NULL,
  `userId` int(11) NOT NULL,
  `type` varchar(191) NOT NULL,
  `provider` varchar(191) NOT NULL,
  `providerAccountId` varchar(191) NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `expires_at` int(11) DEFAULT NULL,
  `token_type` varchar(191) DEFAULT NULL,
  `scope` varchar(191) DEFAULT NULL,
  `id_token` text DEFAULT NULL,
  `session_state` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Account_provider_providerAccountId_key` (`provider`,`providerAccountId`),
  KEY `Account_userId_fkey` (`userId`),
  CONSTRAINT `Account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Alert`
--

DROP TABLE IF EXISTS `Alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Alert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `propertyType` text NOT NULL,
  `district` text NOT NULL,
  `maxPrice` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Alert_email_idx` (`email`),
  KEY `Alert_createdAt_idx` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Alert`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Alert` WRITE;
/*!40000 ALTER TABLE `Alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `Alert` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Appointment`
--

DROP TABLE IF EXISTS `Appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealId` int(11) NOT NULL,
  `proposedById` int(11) NOT NULL,
  `proposedDate` datetime(3) NOT NULL,
  `message` text DEFAULT NULL,
  `type` enum('MEETING','CALL','VIDEO') NOT NULL DEFAULT 'MEETING',
  `status` enum('PENDING','ACCEPTED','DECLINED','RESCHEDULED') NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Appointment_dealId_idx` (`dealId`),
  KEY `Appointment_proposedById_fkey` (`proposedById`),
  CONSTRAINT `Appointment_dealId_fkey` FOREIGN KEY (`dealId`) REFERENCES `Deal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Appointment_proposedById_fkey` FOREIGN KEY (`proposedById`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Appointment`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Appointment` WRITE;
/*!40000 ALTER TABLE `Appointment` DISABLE KEYS */;
INSERT INTO `Appointment` VALUES
(1,9,3,'2026-05-13 11:00:00.000','744433322 Prashant Kontakt','MEETING','RESCHEDULED','2026-05-12 13:20:07.882'),
(2,9,39,'2026-05-14 12:00:00.000','Ok','MEETING','ACCEPTED','2026-05-12 13:20:30.537'),
(3,6,38,'2026-05-14 12:00:00.000','Bbhvgh\n\n[Zgoda na udostępnienie kontaktów]','MEETING','ACCEPTED','2026-05-12 23:48:30.826');
/*!40000 ALTER TABLE `Appointment` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Authenticator`
--

DROP TABLE IF EXISTS `Authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Authenticator` (
  `credentialID` varchar(191) NOT NULL,
  `userId` int(11) NOT NULL,
  `providerAccountId` varchar(191) NOT NULL,
  `credentialPublicKey` varchar(191) NOT NULL,
  `counter` int(11) NOT NULL,
  `credentialDeviceType` varchar(191) NOT NULL,
  `credentialBackedUp` tinyint(1) NOT NULL,
  `transports` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`userId`,`credentialID`),
  UNIQUE KEY `Authenticator_credentialID_key` (`credentialID`),
  CONSTRAINT `Authenticator_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Authenticator`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Authenticator` WRITE;
/*!40000 ALTER TABLE `Authenticator` DISABLE KEYS */;
INSERT INTO `Authenticator` VALUES
('2zcd_aAk-RWI0m4Pn4KmgZibh04',3,'passkey','pQECAyYgASFYIFVMOsjmYhP-zYviCSOAfev5cca6uK3F3RwOCJsDmrK2IlggHHDw0NclN-Joc6PTNrKtfGfpU36rzSVOqI1bhjiRHOY',0,'multiDevice',1,NULL),
('RcRwrP9Mlhwq3SU0TSJKkyF6C3c',3,'passkey_RcRwrP9Mlhwq3SU0','pQECAyYgASFYIL91OUP1mljcm8MUP2PBfd0imJz/kvEmU32O5DEFFS+VIlgguotEwr2tFJHdGFrBFKpa0f1R8Cjo1XWQsLMvzezGQgQ=',0,'multiDevice',1,NULL),
('z7krBPnYwmTUgCpyjoUwmmh6lx4',23,'passkey_z7krBPnYwmTUgCpy','pQECAyYgASFYIDv5P3avlb9cAJm5A2c1X9ngTLXo2OXPHxep5Am6QZ4NIlggn2tKs+az2aM4l+DKR84izkm9ZOyI6CP92CEvqJfgAw0=',0,'multiDevice',1,NULL),
('WQif2RgD66fAkQlR3vSLJjoA_L0',38,'passkey_WQif2RgD66fAkQlR','pQECAyYgASFYIP5ou6s2p9Cu0EDJIjBeVrquvoGeUEZcRHfR1NiAB08QIlgg2FsnCxr9P1RGf5rHtZ0jMFZoRwSzBXQ3zzSai74DDUc=',0,'multiDevice',1,NULL),
('C4KJ7Ck_gcFfQKlXY43ecOaVvbc',39,'passkey_C4KJ7Ck_gcFfQKlX','pQECAyYgASFYIF5jtV89nx3NORtNZWnxQ3y5VbeyoPL/Qby2kC4kczUKIlgg6DgePAO9PC+8pPCrRBx6pXYHt4BMKvJ+21WFgmEjDHw=',0,'multiDevice',1,NULL),
('I6hcHXNW0sfvyv2wame6AB47uKQ',45,'passkey_I6hcHXNW0sfvyv2w','pQECAyYgASFYIGXWJ7NttbBRvSAbw6uoH51KvuSTO9owOatqilIW5tUJIlggFtWR/d4nsImIxBnDXVfb7SZLCgRK8XvQzX7N5FYl4zw=',0,'multiDevice',1,NULL),
('ksknw0WaR5FFXy5_7Xsp-aCrIrI',46,'passkey_ksknw0WaR5FFXy5_','pQECAyYgASFYIEA1b/2bRe0VpbK3+jOA4Pbno1xJ2BEtmYDvIoD1IAYAIlggllKB/Q7W5MRlOeGnEEpvkkQxvQkgyS+sOiQ0j3d5dnU=',0,'multiDevice',1,NULL);
/*!40000 ALTER TABLE `Authenticator` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Bid`
--

DROP TABLE IF EXISTS `Bid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealId` int(11) NOT NULL,
  `senderId` int(11) NOT NULL,
  `amount` double NOT NULL,
  `message` text DEFAULT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED','COUNTER_OFFER') NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Bid_dealId_idx` (`dealId`),
  KEY `Bid_senderId_idx` (`senderId`),
  CONSTRAINT `Bid_dealId_fkey` FOREIGN KEY (`dealId`) REFERENCES `Deal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Bid_senderId_fkey` FOREIGN KEY (`senderId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bid`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Bid` WRITE;
/*!40000 ALTER TABLE `Bid` DISABLE KEYS */;
INSERT INTO `Bid` VALUES
(1,1,23,849000,'Finansowanie: GOTOWKA','COUNTER_OFFER','2026-05-12 06:37:02.622'),
(2,1,3,849500,'Ośrodek','COUNTER_OFFER','2026-05-12 06:38:08.851'),
(3,1,23,849500,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','COUNTER_OFFER','2026-05-12 06:38:22.437'),
(4,1,3,860000,'Yccgv','COUNTER_OFFER','2026-05-12 06:39:34.649'),
(5,1,23,860000,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','COUNTER_OFFER','2026-05-12 06:40:08.620'),
(6,1,3,860000,'M,','COUNTER_OFFER','2026-05-12 06:44:52.858'),
(7,1,23,849000,'Kontroferta','COUNTER_OFFER','2026-05-12 06:46:46.771'),
(8,1,3,849000,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','COUNTER_OFFER','2026-05-12 06:47:02.675'),
(9,5,3,880000,'Co?','REJECTED','2026-05-12 10:49:27.122'),
(10,5,38,875000,'Mogę za tyle.','REJECTED','2026-05-12 10:56:47.131'),
(11,5,3,875000,'Ok?','ACCEPTED','2026-05-12 10:57:42.583'),
(12,6,38,760000,'Misia 🐻','COUNTER_OFFER','2026-05-12 11:14:37.048'),
(13,6,23,761000,'Kontroferta','COUNTER_OFFER','2026-05-12 11:14:56.777'),
(14,6,38,756000,';*','COUNTER_OFFER','2026-05-12 11:15:56.232'),
(16,6,23,757000,'Kontroferta','COUNTER_OFFER','2026-05-12 11:17:07.301'),
(20,6,38,757000,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','COUNTER_OFFER','2026-05-12 11:17:40.914'),
(24,6,23,757000,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','REJECTED','2026-05-12 11:27:03.947'),
(25,6,38,757000,'Misiu ja kupuje ;*','PENDING','2026-05-12 11:28:35.883'),
(26,9,3,806600,'Finansowanie: GOTOWKA','REJECTED','2026-05-12 13:22:10.962'),
(27,9,39,821600,'Deal?','REJECTED','2026-05-12 13:22:36.353'),
(28,9,3,821600,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','ACCEPTED','2026-05-12 13:22:47.627'),
(29,1,23,849000,'Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.','PENDING','2026-05-12 19:25:11.814'),
(30,6,38,800000,'Finansowanie: CASH','PENDING','2026-05-12 23:48:13.261'),
(31,6,38,795000,'Finansowanie: GOTOWKA','PENDING','2026-05-13 08:27:27.478');
/*!40000 ALTER TABLE `Bid` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `CalendarNote`
--

DROP TABLE IF EXISTS `CalendarNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CalendarNote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `date` varchar(32) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CalendarNote_userId_date_key` (`userId`,`date`),
  KEY `CalendarNote_userId_idx` (`userId`),
  CONSTRAINT `CalendarNote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalendarNote`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `CalendarNote` WRITE;
/*!40000 ALTER TABLE `CalendarNote` DISABLE KEYS */;
INSERT INTO `CalendarNote` VALUES
(1,3,'2026-05-07','Zapisuję to czy nie?'),
(2,3,'2026-05-08','Bjzbbvvvv'),
(3,38,'2026-05-08','Nbbnn'),
(4,38,'2026-06-13','Bbvvb');
/*!40000 ALTER TABLE `CalendarNote` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Deal`
--

DROP TABLE IF EXISTS `Deal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Deal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offerId` int(11) NOT NULL,
  `buyerId` int(11) NOT NULL,
  `sellerId` int(11) NOT NULL,
  `status` enum('INITIATED','NEGOTIATION','AGREED','MEETING','FINALIZED','CANCELLED') NOT NULL DEFAULT 'INITIATED',
  `acceptedBidId` int(11) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `finalizedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Deal_offerId_buyerId_key` (`offerId`,`buyerId`),
  UNIQUE KEY `Deal_acceptedBidId_key` (`acceptedBidId`),
  KEY `Deal_buyerId_idx` (`buyerId`),
  KEY `Deal_sellerId_idx` (`sellerId`),
  KEY `Deal_offerId_idx` (`offerId`),
  CONSTRAINT `Deal_acceptedBidId_fkey` FOREIGN KEY (`acceptedBidId`) REFERENCES `Bid` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Deal_buyerId_fkey` FOREIGN KEY (`buyerId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Deal_offerId_fkey` FOREIGN KEY (`offerId`) REFERENCES `Offer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Deal_sellerId_fkey` FOREIGN KEY (`sellerId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Deal`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Deal` WRITE;
/*!40000 ALTER TABLE `Deal` DISABLE KEYS */;
INSERT INTO `Deal` VALUES
(1,152,23,3,'NEGOTIATION',NULL,1,'2026-05-12 06:36:54.869','2026-05-12 19:25:12.059',NULL),
(2,153,3,38,'INITIATED',NULL,1,'2026-05-12 07:29:57.025','2026-05-12 23:42:43.012',NULL),
(3,156,3,23,'INITIATED',NULL,1,'2026-05-12 07:46:41.060','2026-05-12 11:14:30.307',NULL),
(4,116,39,24,'CANCELLED',NULL,0,'2026-05-12 08:57:07.981','2026-05-12 13:19:06.825',NULL),
(5,154,3,38,'AGREED',11,0,'2026-05-12 10:48:59.470','2026-05-12 10:59:49.702',NULL),
(6,114,38,23,'NEGOTIATION',NULL,1,'2026-05-12 11:12:59.574','2026-05-13 08:32:24.325',NULL),
(7,116,3,24,'NEGOTIATION',NULL,1,'2026-05-12 13:16:09.050','2026-05-12 11:25:11.648',NULL),
(9,157,3,39,'AGREED',28,0,'2026-05-12 13:19:48.309','2026-05-12 13:28:04.563',NULL),
(10,164,38,45,'INITIATED',NULL,1,'2026-05-13 08:25:34.750','2026-05-13 08:25:34.750',NULL);
/*!40000 ALTER TABLE `Deal` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DealMessage`
--

DROP TABLE IF EXISTS `DealMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DealMessage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealId` int(11) NOT NULL,
  `senderId` int(11) NOT NULL,
  `content` text NOT NULL,
  `attachment` varchar(191) DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `DealMessage_dealId_idx` (`dealId`),
  KEY `DealMessage_senderId_fkey` (`senderId`),
  CONSTRAINT `DealMessage_dealId_fkey` FOREIGN KEY (`dealId`) REFERENCES `Deal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `DealMessage_senderId_fkey` FOREIGN KEY (`senderId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DealMessage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DealMessage` WRITE;
/*!40000 ALTER TABLE `DealMessage` DISABLE KEYS */;
INSERT INTO `DealMessage` VALUES
(1,1,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"PROPOSED\",\"bidId\":1,\"amount\":849000,\"financing\":\"CASH\",\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:37:02.622Z\"}',NULL,1,'2026-05-12 06:37:02.635'),
(2,1,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":2,\"parentBidId\":1,\"amount\":849500,\"note\":\"Ośrodek\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:38:08.851Z\"}',NULL,1,'2026-05-12 06:38:08.857'),
(3,1,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":3,\"parentBidId\":2,\"amount\":849500,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:38:22.437Z\"}',NULL,1,'2026-05-12 06:38:22.441'),
(4,1,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":4,\"parentBidId\":3,\"amount\":860000,\"note\":\"Yccgv\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:39:34.649Z\"}',NULL,1,'2026-05-12 06:39:34.653'),
(5,1,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":5,\"parentBidId\":4,\"amount\":860000,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:40:08.620Z\"}',NULL,1,'2026-05-12 06:40:08.624'),
(6,1,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":6,\"parentBidId\":5,\"amount\":860000,\"note\":\"M,\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:44:52.858Z\"}',NULL,1,'2026-05-12 06:44:52.867'),
(7,1,3,'[[deal_attachment]]{\"url\":\"/uploads/offers/152/attachments/umowa_najmu_lokalu_uzytkowego_1to1-1778568353439-5953.docx\",\"name\":\"Umowa_najmu_lokalu_uzytkowego_1to1.docx\",\"mimeType\":\"application/vnd.openxmlformats-officedocument.wordprocessingml.document\",\"size\":29498}',NULL,1,'2026-05-12 06:45:53.481'),
(8,1,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":7,\"parentBidId\":6,\"amount\":849000,\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:46:46.771Z\"}',NULL,1,'2026-05-12 06:46:46.775'),
(9,1,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":8,\"parentBidId\":7,\"amount\":849000,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T06:47:02.675Z\"}',NULL,1,'2026-05-12 06:47:02.679'),
(10,3,23,'Mój kochany najfajniejszy mąż',NULL,1,'2026-05-12 10:12:33.100'),
(11,3,3,':*',NULL,1,'2026-05-12 10:12:53.720'),
(12,2,3,'Hej',NULL,1,'2026-05-12 10:44:27.625'),
(13,2,3,'Hg',NULL,1,'2026-05-12 10:44:59.834'),
(14,5,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"PROPOSED\",\"bidId\":9,\"amount\":880000,\"financing\":\"CASH\",\"note\":\"Co?\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T10:49:27.122Z\"}',NULL,1,'2026-05-12 10:49:27.133'),
(15,5,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":10,\"parentBidId\":9,\"amount\":875000,\"note\":\"Mogę za tyle.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T10:56:47.131Z\"}',NULL,1,'2026-05-12 10:56:47.138'),
(16,5,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":11,\"parentBidId\":10,\"amount\":875000,\"note\":\"Ok?\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T10:57:42.583Z\"}',NULL,1,'2026-05-12 10:57:42.588'),
(17,5,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"ACCEPTED\",\"bidId\":11,\"amount\":875000,\"note\":\"Deal\",\"status\":\"ACCEPTED\",\"createdAt\":\"2026-05-12T10:59:49.677Z\"}',NULL,1,'2026-05-12 10:59:49.679'),
(18,2,38,'Bvv',NULL,1,'2026-05-12 11:12:19.157'),
(19,3,23,'Mój kochany najfajniejszy mąż❤️',NULL,1,'2026-05-12 11:14:30.265'),
(20,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"PROPOSED\",\"bidId\":12,\"amount\":760000,\"financing\":\"CASH\",\"note\":\"Misia 🐻\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:14:37.048Z\"}',NULL,1,'2026-05-12 11:14:37.635'),
(21,6,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":13,\"parentBidId\":12,\"amount\":761000,\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:14:56.777Z\"}',NULL,1,'2026-05-12 11:14:56.788'),
(22,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":14,\"parentBidId\":13,\"amount\":756000,\"note\":\";*\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:15:56.232Z\"}',NULL,1,'2026-05-12 11:15:56.243'),
(23,6,38,'🐿️',NULL,1,'2026-05-12 11:16:34.342'),
(25,4,24,'[[DEAL_EVENT]]{\"entity\":\"DEAL\",\"action\":\"CANCELLED\",\"reason\":\"OFFER_SOLD_TO_OTHER\",\"createdAt\":\"2026-05-12T11:17:03.956Z\"}',NULL,1,'2026-05-12 11:17:03.987'),
(26,6,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":16,\"parentBidId\":14,\"amount\":757000,\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:17:07.301Z\"}',NULL,1,'2026-05-12 11:17:07.327'),
(27,6,23,'🙂',NULL,1,'2026-05-12 11:17:16.247'),
(30,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":20,\"parentBidId\":16,\"amount\":757000,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:17:40.914Z\"}',NULL,1,'2026-05-12 11:17:40.920'),
(32,4,24,'[[DEAL_EVENT]]{\"entity\":\"DEAL\",\"action\":\"CANCELLED\",\"reason\":\"OFFER_SOLD_TO_OTHER\",\"createdAt\":\"2026-05-12T11:17:43.487Z\"}',NULL,1,'2026-05-12 11:17:43.515'),
(34,4,24,'[[DEAL_EVENT]]{\"entity\":\"DEAL\",\"action\":\"CANCELLED\",\"reason\":\"OFFER_SOLD_TO_OTHER\",\"createdAt\":\"2026-05-12T11:24:49.628Z\"}',NULL,1,'2026-05-12 11:24:49.654'),
(35,4,24,'[[DEAL_EVENT]]{\"entity\":\"DEAL\",\"action\":\"CANCELLED\",\"reason\":\"OFFER_SOLD_TO_OTHER\",\"createdAt\":\"2026-05-12T11:25:11.653Z\"}',NULL,1,'2026-05-12 11:25:11.674'),
(37,6,23,'Możemy tak pisać bez końca 🙂',NULL,1,'2026-05-12 11:26:54.836'),
(38,6,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":24,\"parentBidId\":20,\"amount\":757000,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:27:03.947Z\"}',NULL,1,'2026-05-12 11:27:03.952'),
(39,6,38,'Misia jeśli u ciebie pluka cały czas coś to to nie ja piszę tylko serwer się naprawia',NULL,1,'2026-05-12 11:27:26.795'),
(40,6,23,'Negocjacje',NULL,1,'2026-05-12 11:27:46.124'),
(41,6,38,'Na jakieś pół godzinki po prostu nie zwracaj uwagi',NULL,1,'2026-05-12 11:27:49.397'),
(42,6,23,'Już zaakceptowałam',NULL,1,'2026-05-12 11:27:54.166'),
(43,6,38,'Dokładnie serwer zamyka zaległości',NULL,1,'2026-05-12 11:27:59.212'),
(44,6,23,'🙂',NULL,1,'2026-05-12 11:28:32.156'),
(45,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":25,\"parentBidId\":24,\"amount\":757000,\"note\":\"Misiu ja kupuje ;*\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T11:28:35.883Z\"}',NULL,1,'2026-05-12 11:28:35.890'),
(46,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"REJECTED\",\"status\":\"REJECTED\",\"bidId\":24,\"amount\":757000,\"note\":null,\"message\":null,\"createdAt\":\"2026-05-12T12:39:05.091Z\"}',NULL,1,'2026-05-12 12:39:05.093'),
(47,9,3,'[[DEAL_EVENT]]{\"entity\":\"APPOINTMENT\",\"action\":\"PROPOSED\",\"appointmentId\":1,\"proposedDate\":\"2026-05-13T11:00:00.000Z\",\"note\":\"744433322 Prashant Kontakt\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T13:20:07.882Z\"}',NULL,1,'2026-05-12 13:20:07.898'),
(48,9,39,'[[DEAL_EVENT]]{\"entity\":\"APPOINTMENT\",\"action\":\"COUNTERED\",\"appointmentId\":2,\"parentAppointmentId\":1,\"proposedDate\":\"2026-05-14T12:00:00.000Z\",\"note\":\"Ok\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T13:20:30.537Z\"}',NULL,1,'2026-05-12 13:20:30.542'),
(49,9,3,'[[DEAL_EVENT]]{\"entity\":\"APPOINTMENT\",\"action\":\"ACCEPTED\",\"appointmentId\":2,\"proposedDate\":\"2026-05-14T12:00:00.000Z\",\"note\":\"Akceptuję termin\",\"status\":\"ACCEPTED\",\"createdAt\":\"2026-05-12T13:20:40.485Z\"}',NULL,1,'2026-05-12 13:20:40.486'),
(50,9,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"PROPOSED\",\"bidId\":26,\"amount\":806600,\"financing\":\"CASH\",\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T13:22:10.962Z\"}',NULL,1,'2026-05-12 13:22:10.976'),
(51,9,39,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":27,\"parentBidId\":26,\"amount\":821600,\"note\":\"Deal?\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T13:22:36.353Z\"}',NULL,1,'2026-05-12 13:22:36.358'),
(52,9,3,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":28,\"parentBidId\":27,\"amount\":821600,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T13:22:47.627Z\"}',NULL,1,'2026-05-12 13:22:47.632'),
(53,9,39,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"ACCEPTED\",\"bidId\":28,\"amount\":821600,\"note\":\"\",\"status\":\"ACCEPTED\",\"createdAt\":\"2026-05-12T13:27:59.245Z\"}',NULL,1,'2026-05-12 13:27:59.246'),
(54,9,39,'Decyzja właściciela: ostatecznie akceptuję cenę 821 600 PLN i zamykam sprzedaż. Oferta została wycofana z rynku.',NULL,1,'2026-05-12 13:28:04.554'),
(55,1,23,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"COUNTERED\",\"bidId\":29,\"parentBidId\":8,\"amount\":849000,\"note\":\"Akceptuję Twoją cenę. Proszę o ostateczne potwierdzenie sprzedaży.\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-12T19:25:11.814Z\"}',NULL,1,'2026-05-12 19:25:11.821'),
(56,2,38,'Jvvv vbb',NULL,0,'2026-05-12 23:42:42.998'),
(57,6,38,'💰 Złożono oficjalną ofertę zakupu na kwotę: 800 000 PLN. Finansowanie: CASH',NULL,1,'2026-05-12 23:48:13.283'),
(58,6,38,'[[DEAL_EVENT]]{\"entity\":\"APPOINTMENT\",\"action\":\"PROPOSED\",\"status\":\"PENDING\",\"appointmentId\":3,\"proposedDate\":\"2026-05-14T12:00:00.000Z\",\"note\":\"Bbhvgh\\n\\n[Zgoda na udostępnienie kontaktów]\",\"message\":\"Bbhvgh\\n\\n[Zgoda na udostępnienie kontaktów]\",\"createdAt\":\"2026-05-12T23:48:30.826Z\"}',NULL,1,'2026-05-12 23:48:30.841'),
(59,6,38,'📎 IMG_5362.png','/uploads/offers/114/attachments/deal-ae9a08ea-6299-419a-b692-5901ac5bc49e.webp',1,'2026-05-12 23:53:54.982'),
(60,6,38,'Misia 🐻',NULL,1,'2026-05-13 08:26:25.193'),
(61,6,38,'[[DEAL_EVENT]]{\"entity\":\"BID\",\"action\":\"PROPOSED\",\"bidId\":31,\"amount\":795000,\"financing\":\"CASH\",\"note\":\"\",\"status\":\"PENDING\",\"createdAt\":\"2026-05-13T08:27:27.478Z\"}',NULL,1,'2026-05-13 08:27:27.495'),
(62,6,23,'😍',NULL,1,'2026-05-13 08:27:53.759'),
(63,6,23,'[[DEAL_EVENT]]{\"entity\":\"APPOINTMENT\",\"action\":\"ACCEPTED\",\"appointmentId\":3,\"proposedDate\":\"2026-05-14T12:00:00.000Z\",\"note\":\"Akceptuję termin\",\"status\":\"ACCEPTED\",\"createdAt\":\"2026-05-13T08:27:59.760Z\"}',NULL,1,'2026-05-13 08:27:59.762'),
(64,6,23,'Zapisało w kalendarzu 😃',NULL,1,'2026-05-13 08:28:44.086'),
(65,6,38,':*',NULL,1,'2026-05-13 08:28:51.460'),
(66,6,23,'❤️',NULL,1,'2026-05-13 08:29:24.071'),
(67,6,38,'Misia wyślesz mi kontrofertę?',NULL,1,'2026-05-13 08:30:18.898'),
(68,6,38,'I czy ty masz najnowszą wersję czy Widzisz ten zegarek?',NULL,1,'2026-05-13 08:30:30.025'),
(69,6,23,'Tak',NULL,1,'2026-05-13 08:30:56.052'),
(70,6,23,'Widzę',NULL,1,'2026-05-13 08:30:58.042'),
(71,6,38,'Zaakceptujesz cenę?',NULL,1,'2026-05-13 08:32:24.315');
/*!40000 ALTER TABLE `DealMessage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Device`
--

DROP TABLE IF EXISTS `Device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Device` (
  `id` varchar(191) NOT NULL,
  `userId` int(11) NOT NULL,
  `expoPushToken` varchar(191) NOT NULL,
  `platform` enum('IOS','ANDROID','WEB') NOT NULL DEFAULT 'IOS',
  `deviceModel` varchar(191) DEFAULT NULL,
  `appVersion` varchar(191) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `lastSyncedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Device_userId_expoPushToken_key` (`userId`,`expoPushToken`),
  KEY `Device_userId_idx` (`userId`),
  CONSTRAINT `Device_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Device`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Device` WRITE;
/*!40000 ALTER TABLE `Device` DISABLE KEYS */;
INSERT INTO `Device` VALUES
('cmoe5584c000hm5eor4udrzbj',3,'ExponentPushToken[LcEn0uDuS28cUp30RMXj8T]','IOS','iPad14,6','1.0.0',1,'2026-05-12 23:42:44.842','2026-04-25 09:32:34.524','2026-05-12 23:42:44.843'),
('cmoeplzq7001j8tjxr8wndvsi',23,'ExponentPushToken[reqIdwNIdnVMd1o6tj3r5N]','IOS','iPhone 17 Pro','1.0.0',1,'2026-05-13 08:32:26.263','2026-04-25 19:05:29.118','2026-05-13 08:32:26.265'),
('cmoew2ts600358tjx0lprddpo',3,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',0,'2026-05-12 17:47:12.369','2026-04-25 22:06:32.262','2026-05-13 14:41:40.772'),
('cmojd8cjj001x12p9wv2t5u9z',3,'ExponentPushToken[5JdrScGIAMJP08OSpuHQQT]','IOS','iPad Pro (12.9-inch) (3rd generation)','1.0.0',1,'2026-05-12 23:42:44.842','2026-04-29 01:17:48.032','2026-05-12 23:42:44.843'),
('cmopgrs7u0036igp29ov07at7',23,'ExponentPushToken[LcEn0uDuS28cUp30RMXj8T]','IOS','iPad14,6','1.0.0',0,'2026-05-04 17:26:10.457','2026-05-03 07:43:30.714','2026-05-12 19:29:34.674'),
('cmp1kx5xt000ncvbhkh5kzsem',36,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',0,'2026-05-11 19:12:54.354','2026-05-11 19:12:54.354','2026-05-13 14:41:40.772'),
('cmp1nuiwc001gcvbh9x8cld2h',38,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',0,'2026-05-13 11:13:22.572','2026-05-11 20:34:50.028','2026-05-13 14:41:40.772'),
('cmp2dv0wq002187svi6qlryeb',39,'ExponentPushToken[1-jqBrHj52kczUDSf_GgTE]','IOS','iPhone XS','1.0.0',1,'2026-05-12 14:35:20.271','2026-05-12 08:43:03.386','2026-05-12 14:35:20.274'),
('cmp2skr4000025v2bl78m46po',39,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',0,'2026-05-12 15:34:58.429','2026-05-12 15:34:58.369','2026-05-13 14:41:40.772'),
('cmp2udmd80002xwayojzo798b',45,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',0,'2026-05-12 18:09:04.018','2026-05-12 16:25:24.860','2026-05-13 14:41:40.772'),
('cmp3yr6420023eiimpw4ov80g',46,'ExponentPushToken[GJjXIKAYymhg21nO5YjLk2]','IOS','iPhone 15 Pro Max','1.0.0',1,'2026-05-13 14:41:40.775','2026-05-13 11:15:41.618','2026-05-13 14:41:40.776');
/*!40000 ALTER TABLE `Device` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DevicePushPreference`
--

DROP TABLE IF EXISTS `DevicePushPreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DevicePushPreference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `favoritesEnabled` tinyint(1) NOT NULL DEFAULT 1,
  `notifyPriceChange` tinyint(1) NOT NULL DEFAULT 1,
  `notifyDealProposals` tinyint(1) NOT NULL DEFAULT 1,
  `notifyIncludeAmounts` tinyint(1) NOT NULL DEFAULT 1,
  `notifyStatusChange` tinyint(1) NOT NULL DEFAULT 1,
  `notifyNewSimilar` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DevicePushPreference_userId_key` (`userId`),
  CONSTRAINT `DevicePushPreference_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=211370 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DevicePushPreference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DevicePushPreference` WRITE;
/*!40000 ALTER TABLE `DevicePushPreference` DISABLE KEYS */;
INSERT INTO `DevicePushPreference` VALUES
(211355,3,0,1,1,1,1,1,'2026-05-10 14:05:47.109','2026-05-12 19:29:34.691'),
(211356,23,0,1,1,1,1,1,'2026-05-10 15:30:45.153','2026-05-13 08:26:57.797'),
(211364,36,0,1,1,1,1,1,'2026-05-11 19:12:54.362','2026-05-11 19:12:54.362'),
(211366,38,0,1,1,1,1,1,'2026-05-11 20:34:50.036','2026-05-13 11:13:22.585'),
(211367,39,0,1,1,1,1,1,'2026-05-12 08:43:03.409','2026-05-12 15:34:58.442'),
(211368,45,0,1,1,1,1,1,'2026-05-12 16:25:24.872','2026-05-12 18:09:04.032'),
(211369,46,0,1,1,1,1,1,'2026-05-13 11:15:41.627','2026-05-13 14:41:40.786');
/*!40000 ALTER TABLE `DevicePushPreference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DiscoveryEvent`
--

DROP TABLE IF EXISTS `DiscoveryEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DiscoveryEvent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `eventType` varchar(64) NOT NULL,
  `offerId` int(11) NOT NULL,
  `photoIndex` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `reasonCode` varchar(64) DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'mobile_discovery',
  `platform` varchar(16) NOT NULL,
  `at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `DiscoveryEvent_user_created_idx` (`userId`,`createdAt`),
  KEY `DiscoveryEvent_user_event_idx` (`userId`,`eventType`),
  KEY `DiscoveryEvent_offer_created_idx` (`offerId`,`createdAt`),
  CONSTRAINT `DiscoveryEvent_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DiscoveryEvent`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DiscoveryEvent` WRITE;
/*!40000 ALTER TABLE `DiscoveryEvent` DISABLE KEYS */;
INSERT INTO `DiscoveryEvent` VALUES
(1,38,'DISCOVERY_OPEN',164,0,50,NULL,'mobile_discovery','ios','2026-05-13 08:40:33.499','2026-05-13 08:40:33.737'),
(2,38,'DISCOVERY_OPEN',164,1,50,NULL,'mobile_discovery','ios','2026-05-13 08:40:47.102','2026-05-13 08:40:47.335');
/*!40000 ALTER TABLE `DiscoveryEvent` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `DiscoveryProfile`
--

DROP TABLE IF EXISTS `DiscoveryProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DiscoveryProfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `likesCount` int(11) NOT NULL DEFAULT 0,
  `dislikesCount` int(11) NOT NULL DEFAULT 0,
  `fastTrackCount` int(11) NOT NULL DEFAULT 0,
  `opensCount` int(11) NOT NULL DEFAULT 0,
  `reasonStats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`reasonStats`)),
  `cityStats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`cityStats`)),
  `districtStats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`districtStats`)),
  `propertyStats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`propertyStats`)),
  `updatedAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `DiscoveryProfile_userId_key` (`userId`),
  CONSTRAINT `DiscoveryProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DiscoveryProfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `DiscoveryProfile` WRITE;
/*!40000 ALTER TABLE `DiscoveryProfile` DISABLE KEYS */;
INSERT INTO `DiscoveryProfile` VALUES
(1,38,0,0,0,2,'{}','{}','{}','{}','2026-05-13 08:40:47.348','2026-05-13 08:40:33.769');
/*!40000 ALTER TABLE `DiscoveryProfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `FavoriteOffer`
--

DROP TABLE IF EXISTS `FavoriteOffer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `FavoriteOffer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `offerId` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FavoriteOffer_userId_offerId_key` (`userId`,`offerId`),
  KEY `FavoriteOffer_offerId_idx` (`offerId`),
  KEY `FavoriteOffer_userId_idx` (`userId`),
  CONSTRAINT `FavoriteOffer_offerId_fkey` FOREIGN KEY (`offerId`) REFERENCES `Offer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FavoriteOffer_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FavoriteOffer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `FavoriteOffer` WRITE;
/*!40000 ALTER TABLE `FavoriteOffer` DISABLE KEYS */;
/*!40000 ALTER TABLE `FavoriteOffer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `IapTransaction`
--

DROP TABLE IF EXISTS `IapTransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `IapTransaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `transactionId` varchar(128) NOT NULL,
  `originalTransactionId` varchar(128) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `productId` varchar(128) NOT NULL,
  `platform` varchar(16) NOT NULL,
  `environment` varchar(32) DEFAULT NULL,
  `bundleId` varchar(128) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `purchaseDate` datetime(3) DEFAULT NULL,
  `expiresDate` datetime(3) DEFAULT NULL,
  `creditedExtraListings` int(11) NOT NULL DEFAULT 0,
  `creditedPlusDays` int(11) NOT NULL DEFAULT 0,
  `rawPayloadHash` varchar(64) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `processedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IapTransaction_transactionId_key` (`transactionId`),
  KEY `IapTransaction_userId_idx` (`userId`),
  KEY `IapTransaction_originalTransactionId_idx` (`originalTransactionId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IapTransaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `IapTransaction` WRITE;
/*!40000 ALTER TABLE `IapTransaction` DISABLE KEYS */;
INSERT INTO `IapTransaction` VALUES
(5,'2000001168525224','2000001168525224',23,'pl.estateos.app.pakiet_plus_30d','ios','Sandbox','pl.estateos.app',1,'2026-05-12 06:27:53.000',NULL,1,0,'25e4266358cf677c1b6a89285ffcec6bf95ea4c2c03f1d64da1bbe00784266aa','2026-05-12 19:24:48.348','2026-05-12 19:24:48.348');
/*!40000 ALTER TABLE `IapTransaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `LeadTransfer`
--

DROP TABLE IF EXISTS `LeadTransfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `LeadTransfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offerId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `agencyId` int(11) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `price` double DEFAULT NULL,
  `message` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `commissionRate` double DEFAULT NULL,
  `commissionTerms` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `LeadTransfer_offerId_idx` (`offerId`),
  KEY `LeadTransfer_ownerId_idx` (`ownerId`),
  KEY `LeadTransfer_agencyId_idx` (`agencyId`),
  CONSTRAINT `LeadTransfer_agencyId_fkey` FOREIGN KEY (`agencyId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `LeadTransfer_offerId_fkey` FOREIGN KEY (`offerId`) REFERENCES `Offer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `LeadTransfer_ownerId_fkey` FOREIGN KEY (`ownerId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LeadTransfer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `LeadTransfer` WRITE;
/*!40000 ALTER TABLE `LeadTransfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `LeadTransfer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` varchar(191) NOT NULL,
  `userId` int(11) NOT NULL,
  `idempotencyKey` varchar(191) DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `body` text NOT NULL,
  `type` enum('MESSAGE','DEAL_UPDATE','BID_RECEIVED','APPOINTMENT','SYSTEM_ALERT','AI_RADAR','MARKETING') NOT NULL DEFAULT 'SYSTEM_ALERT',
  `priority` enum('LOW','NORMAL','HIGH','CRITICAL') NOT NULL DEFAULT 'NORMAL',
  `delivery` enum('SILENT','STANDARD','WAKE_SCREEN') NOT NULL DEFAULT 'STANDARD',
  `status` enum('PENDING','SENT','DELIVERED','READ','FAILED') NOT NULL DEFAULT 'PENDING',
  `soundKey` varchar(191) DEFAULT NULL,
  `targetType` enum('OFFER','DEAL','CHAT','USER') DEFAULT NULL,
  `targetId` varchar(191) DEFAULT NULL,
  `sentAt` datetime(3) DEFAULT NULL,
  `deliveredAt` datetime(3) DEFAULT NULL,
  `readAt` datetime(3) DEFAULT NULL,
  `failedAt` datetime(3) DEFAULT NULL,
  `failureReason` text DEFAULT NULL,
  `isArchived` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Notification_userId_idempotencyKey_key` (`userId`,`idempotencyKey`),
  KEY `Notification_userId_status_idx` (`userId`,`status`),
  KEY `Notification_userId_createdAt_idx` (`userId`,`createdAt`),
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
INSERT INTO `Notification` VALUES
('cmoepxnx2001n8tjxvutgrql6',23,NULL,'💎 Idealne trafienie','Świetna nieruchomość na Białołęce • 489000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:14:34.181',NULL,NULL,NULL,NULL,0,'2026-04-25 19:14:33.685','2026-04-25 19:14:34.184'),
('cmoeqsm8100218tjxvc1jzecr',23,NULL,'💎 Idealne trafienie','Świetna nieruchomość na Białołęce • 489000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:38:38.036',NULL,NULL,NULL,NULL,0,'2026-04-25 19:38:37.825','2026-04-25 19:38:38.037'),
('cmoeqvyq900258tjxjd0qgcvd',23,NULL,'🔥 Świeża okazja','Świetna nieruchomość na Białołęce • 489000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:41:14.212',NULL,NULL,NULL,NULL,0,'2026-04-25 19:41:14.002','2026-04-25 19:41:14.215'),
('cmoeqxyx900278tjxtogn1rm0',23,NULL,'🔥 Świeża okazja','Świetna oferta we Wrocławiu • 777777 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:42:47.887',NULL,NULL,NULL,NULL,0,'2026-04-25 19:42:47.565','2026-04-25 19:42:47.889'),
('cmoeqz4xw002b8tjx4khrf8cf',23,NULL,'🔥 Świeża okazja','Świetna oferta we Wrocławiu • 777777 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:43:42.394',NULL,NULL,NULL,NULL,0,'2026-04-25 19:43:42.021','2026-04-25 19:43:42.396'),
('cmoer0773002f8tjxas4utzh0',23,NULL,'🔥 Świeża okazja','Ofjgvhcvjgcjg • 333333 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-25 19:44:31.912',NULL,NULL,NULL,NULL,0,'2026-04-25 19:44:31.599','2026-04-25 19:44:31.913'),
('cmofiqu53000xedvl2jdx2mrw',23,NULL,'🔥 Świeża okazja','Luksusowy apartament z widokiem na stare miasto • 949000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-26 08:41:04.476',NULL,NULL,NULL,NULL,0,'2026-04-26 08:41:04.023','2026-04-26 08:41:04.477'),
('cmofisnp60011edvl8eam94z8',23,NULL,'🔥 Świeża okazja','Cudownej apartament w Sopocie • 850000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-26 08:42:29.194',NULL,NULL,NULL,NULL,0,'2026-04-26 08:42:28.986','2026-04-26 08:42:29.196'),
('cmoh85sjb0001l5d4ybo1qqdw',23,NULL,'⭐ Otrzymałeś nową ocenę: 5/5','Dodano nową, bardzo pozytywną opinię o Twojej współpracy.','SYSTEM_ALERT','NORMAL','STANDARD','PENDING',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-04-27 13:20:18.360','2026-04-27 13:20:18.360'),
('cmohtj2ce002lx39a86pew2zy',3,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-27 23:18:29.733',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-27 23:18:29.534','2026-04-30 09:23:45.529'),
('cmohu4mon003fx39aao3t4ae6',3,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-27 23:35:15.849',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-27 23:35:15.671','2026-04-30 09:23:45.529'),
('cmohu4mtz003hx39adiohrzj1',24,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-27 23:35:15.877','NO_ACTIVE_DEVICES',0,'2026-04-27 23:35:15.863','2026-04-27 23:35:15.880'),
('cmoiko5zi000tdtqj6lv709yw',3,NULL,'🔥 Świeża okazja','BC. Vzcnvxzzbxxbx • 888888 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-28 11:58:17.398',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-28 11:58:17.167','2026-04-30 09:23:45.529'),
('cmoiko66a000vdtqjfusu7tyf',24,NULL,'🔥 Świeża okazja','BC. Vzcnvxzzbxxbx • 888888 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-28 11:58:17.418','NO_ACTIVE_DEVICES',0,'2026-04-28 11:58:17.410','2026-04-28 11:58:17.421'),
('cmoj102qw000r12p961ygqp3e',3,NULL,'🔥 Świeża okazja','Bsbsvslasvsvs • 350000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-28 19:35:27.188',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-28 19:35:26.696','2026-04-30 09:23:45.529'),
('cmoj3qqnv001112p9jqmb4mlz',3,NULL,'🔥 Świeża okazja','Wspaniały apartament w Łania • 404300 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-28 20:52:10.395',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-28 20:52:09.979','2026-04-30 09:23:45.529'),
('cmojdjmgl002512p9ecamio8t',23,NULL,'💎 Idealne trafienie','I ci Ig i Ig  • 333333 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-29 01:26:34.725',NULL,NULL,NULL,NULL,0,'2026-04-29 01:26:34.101','2026-04-29 01:26:34.727'),
('cmojdjmye002712p9k2vwmurc',24,NULL,'🔥 Świeża okazja','I ci Ig i Ig  • 333333 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 01:26:34.752','NO_ACTIVE_DEVICES',0,'2026-04-29 01:26:34.742','2026-04-29 01:26:34.754'),
('cmojdk7q0002b12p9i0e2bd8h',3,NULL,'💎 Idealne trafienie','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-29 01:27:01.870',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-29 01:27:01.656','2026-04-30 09:23:45.529'),
('cmojdk7wg002d12p9okv4w8mk',24,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 01:27:01.902','NO_ACTIVE_DEVICES',0,'2026-04-29 01:27:01.888','2026-04-29 01:27:01.903'),
('cmok2skn10003ar4dnpd3g1os',24,NULL,'🔥 Świeża okazja','nieruchomość na Pradze  • 850000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 13:13:22.060','NO_ACTIVE_DEVICES',0,'2026-04-29 13:13:22.045','2026-04-29 13:13:22.061'),
('cmokd7amp0007ar4dhkd51ndk',3,NULL,'🎯 Właśnie wpadła','BC. Vzcnvxzzbxxbx • 888888 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-29 18:04:45.283',NULL,'2026-04-29 21:33:54.507',NULL,NULL,0,'2026-04-29 18:04:45.073','2026-04-29 21:33:54.509'),
('cmokd7asw0009ar4dxaytlusy',24,NULL,'🔥 Świeża okazja','BC. Vzcnvxzzbxxbx • 888888 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 18:04:45.305','NO_ACTIVE_DEVICES',0,'2026-04-29 18:04:45.297','2026-04-29 18:04:45.307'),
('cmokl360f0003jz9uxa4dx1zj',3,NULL,'🎯 Właśnie wpadła','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-29 21:45:29.981',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-29 21:45:29.391','2026-04-30 09:23:45.529'),
('cmokl36hd0005jz9um98kj8tn',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 21:45:30.014','NO_ACTIVE_DEVICES',0,'2026-04-29 21:45:30.001','2026-04-29 21:45:30.015'),
('cmokl7bkn0009jz9ugpb2o51t',3,NULL,'🎯 Właśnie wpadła','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-29 21:48:43.722',NULL,'2026-04-30 09:23:45.528',NULL,NULL,0,'2026-04-29 21:48:43.223','2026-04-30 09:23:45.529'),
('cmokl7bza000bjz9uzce8cqal',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 21:48:43.765','NO_ACTIVE_DEVICES',0,'2026-04-29 21:48:43.750','2026-04-29 21:48:43.767'),
('cmokov5jd000chyh3l4okowhb',24,NULL,'🔥 Świeża okazja','nieruchomość na Pradze  • 850000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-29 23:31:14.004','NO_ACTIVE_DEVICES',0,'2026-04-29 23:31:13.993','2026-04-29 23:31:14.005'),
('cmolbqi810039z4ux96uma3br',3,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 10:11:28.710',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 10:11:28.322','2026-05-06 07:43:17.079'),
('cmolbqijb003bz4uxvo6zlf4x',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-30 10:11:28.933',NULL,NULL,NULL,NULL,0,'2026-04-30 10:11:28.727','2026-04-30 10:11:28.934'),
('cmolbrsv3003gz4uxoi6ktdtw',3,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 10:12:29.074',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 10:12:28.767','2026-05-06 07:43:17.079'),
('cmolbrt40003iz4uxwxkvuhrj',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-30 10:12:29.284',NULL,NULL,NULL,NULL,0,'2026-04-30 10:12:29.088','2026-04-30 10:12:29.286'),
('cmoldjf3q003nz4ux6q475xnf',3,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 11:01:57.317',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 11:01:56.919','2026-05-06 07:43:17.079'),
('cmoldjff7003pz4ux483k7n0n',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-30 11:01:57.527',NULL,NULL,NULL,NULL,0,'2026-04-30 11:01:57.331','2026-04-30 11:01:57.528'),
('cmom4rttl000gs6ub8ami6h0q',3,NULL,'💎 Idealne trafienie','BC cgicixhixohc uff xt • 888888 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 23:44:19.157',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 23:44:18.874','2026-05-06 07:43:17.079'),
('cmom4ru1w000is6ub8bpfq9qe',24,NULL,'🔥 Świeża okazja','BC cgicixhixohc uff xt • 888888 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-30 23:44:19.188','NO_ACTIVE_DEVICES',0,'2026-04-30 23:44:19.172','2026-04-30 23:44:19.190'),
('cmom4s53a000os6ubk5o489b0',3,NULL,'💎 Idealne trafienie','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 23:44:33.778',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 23:44:33.478','2026-05-06 07:43:17.079'),
('cmom4s5c2000qs6ubejkgdw36',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-30 23:44:33.806','NO_ACTIVE_DEVICES',0,'2026-04-30 23:44:33.795','2026-04-30 23:44:33.808'),
('cmom4yzsm000ws6ubx6vmc9wy',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-04-30 23:49:53.606',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-04-30 23:49:53.207','2026-05-06 07:43:17.079'),
('cmom4z048000ys6ubnutrdlck',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-04-30 23:49:53.821',NULL,NULL,NULL,NULL,0,'2026-04-30 23:49:53.624','2026-04-30 23:49:53.822'),
('cmomozlnd0012s6ubn46ybwk0',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-05-01 09:10:14.611',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-05-01 09:10:13.849','2026-05-06 07:43:17.079'),
('cmomozm900014s6ubhjhk4qpa',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 09:10:14.850',NULL,NULL,NULL,NULL,0,'2026-05-01 09:10:14.628','2026-05-01 09:10:14.851'),
('cmomp07jf0018s6ub47llf5it',3,NULL,'🎯 Właśnie wpadła','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-05-01 09:10:42.539',NULL,'2026-05-06 07:43:17.078',NULL,NULL,0,'2026-05-01 09:10:42.219','2026-05-06 07:43:17.079'),
('cmomp07sl001as6ubq6k3vi4c',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-01 09:10:42.557','NO_ACTIVE_DEVICES',0,'2026-05-01 09:10:42.550','2026-05-01 09:10:42.559'),
('cmomteuz30004d72mvcltr4q7',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:14:04.260','NO_ACTIVE_DEVICES',0,'2026-05-01 11:14:04.240','2026-05-06 07:43:17.079'),
('cmomteuzz0006d72mjw20e1us',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:14:06.070',NULL,NULL,NULL,NULL,0,'2026-05-01 11:14:04.271','2026-05-01 11:14:06.071'),
('cmomtflqb000cd72mw45x084w',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:14:38.927','NO_ACTIVE_DEVICES',0,'2026-05-01 11:14:38.916','2026-05-06 07:43:17.079'),
('cmomtflqz000ed72mbu9kwnhs',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:14:40.627',NULL,NULL,NULL,NULL,0,'2026-05-01 11:14:38.939','2026-05-01 11:14:40.629'),
('cmomtgldu000nd72me4m1e14y',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:15:25.130','NO_ACTIVE_DEVICES',0,'2026-05-01 11:15:25.122','2026-05-06 07:43:17.079'),
('cmomtgleb000pd72mv0mmq34a',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:15:26.871',NULL,NULL,NULL,NULL,0,'2026-05-01 11:15:25.140','2026-05-01 11:15:26.872'),
('cmomtj5l7000vd72mehdz072o',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:17:24.629','NO_ACTIVE_DEVICES',0,'2026-05-01 11:17:24.619','2026-05-06 07:43:17.079'),
('cmomtj5lt000xd72ml53j3kub',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:17:26.345',NULL,NULL,NULL,NULL,0,'2026-05-01 11:17:24.642','2026-05-01 11:17:26.347'),
('cmomtjh280013d72mm0tsbnt7',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:17:39.501','NO_ACTIVE_DEVICES',0,'2026-05-01 11:17:39.489','2026-05-06 07:43:17.079'),
('cmomtjh2v0015d72mtkzdfjbr',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:17:41.168',NULL,NULL,NULL,NULL,0,'2026-05-01 11:17:39.512','2026-05-01 11:17:41.169'),
('cmomtjzol001ed72megv3i0o5',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:18:03.637','NO_ACTIVE_DEVICES',0,'2026-05-01 11:18:03.621','2026-05-06 07:43:17.079'),
('cmomtjzpa001gd72m3u6p2kp4',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:18:05.324',NULL,NULL,NULL,NULL,0,'2026-05-01 11:18:03.647','2026-05-01 11:18:05.325'),
('cmomtldf2001md72mhszdfed3',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:19:08.089','NO_ACTIVE_DEVICES',0,'2026-05-01 11:19:08.078','2026-05-06 07:43:17.079'),
('cmomtldfl001od72mw0na79z8',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:19:09.754',NULL,NULL,NULL,NULL,0,'2026-05-01 11:19:08.098','2026-05-01 11:19:09.755'),
('cmomtlxgc001ud72my9w8eru7',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:19:34.053','NO_ACTIVE_DEVICES',0,'2026-05-01 11:19:34.044','2026-05-06 07:43:17.079'),
('cmomtlxgu001wd72mpwdimiji',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:19:35.760',NULL,NULL,NULL,NULL,0,'2026-05-01 11:19:34.063','2026-05-01 11:19:35.761'),
('cmomtmwll0022d72mj9ruo2fp',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:20:19.603','NO_ACTIVE_DEVICES',0,'2026-05-01 11:20:19.589','2026-05-06 07:43:17.079'),
('cmomtmwm30024d72muzete1us',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:20:21.324',NULL,NULL,NULL,NULL,0,'2026-05-01 11:20:19.612','2026-05-01 11:20:21.328'),
('cmomtnrd7002dd72mo9hf0xvl',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:20:59.478','NO_ACTIVE_DEVICES',0,'2026-05-01 11:20:59.467','2026-05-06 07:43:17.079'),
('cmomtnrds002fd72m2pytgmt2',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:21:01.258',NULL,NULL,NULL,NULL,0,'2026-05-01 11:20:59.488','2026-05-01 11:21:01.259'),
('cmomtpbos002ld72mnbmh3myi',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:22:12.474','NO_ACTIVE_DEVICES',0,'2026-05-01 11:22:12.461','2026-05-06 07:43:17.079'),
('cmomtpbpt002nd72mdbqtguzi',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:22:14.246',NULL,NULL,NULL,NULL,0,'2026-05-01 11:22:12.497','2026-05-01 11:22:14.247'),
('cmomtqu06002zd72mu47h82ca',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:23:22.865','NO_ACTIVE_DEVICES',0,'2026-05-01 11:23:22.854','2026-05-06 07:43:17.079'),
('cmomtqu0r0031d72muy1837gc',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:23:24.854',NULL,NULL,NULL,NULL,0,'2026-05-01 11:23:22.876','2026-05-01 11:23:24.856'),
('cmomtspwc0037d72mh64paiil',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:24:50.856','NO_ACTIVE_DEVICES',0,'2026-05-01 11:24:50.844','2026-05-06 07:43:17.079'),
('cmomtspwx0039d72mljtzohiy',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:24:52.566',NULL,NULL,NULL,NULL,0,'2026-05-01 11:24:50.865','2026-05-01 11:24:52.570'),
('cmomtt1nl003fd72mrgtag6oe',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:25:06.091','NO_ACTIVE_DEVICES',0,'2026-05-01 11:25:06.081','2026-05-06 07:43:17.079'),
('cmomtt1o3003hd72mwoy9jo3f',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:25:07.799',NULL,NULL,NULL,NULL,0,'2026-05-01 11:25:06.100','2026-05-01 11:25:07.801'),
('cmomttfmo003nd72mjiw4vesa',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:25:24.203','NO_ACTIVE_DEVICES',0,'2026-05-01 11:25:24.192','2026-05-06 07:43:17.079'),
('cmomttfn8003pd72mg44ukrzy',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:25:25.872',NULL,NULL,NULL,NULL,0,'2026-05-01 11:25:24.212','2026-05-01 11:25:25.874'),
('cmomtvjak003vd72ml35ub78d',3,NULL,'💎 Idealne trafienie','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:27:02.262','NO_ACTIVE_DEVICES',0,'2026-05-01 11:27:02.252','2026-05-06 07:43:17.079'),
('cmomtvjb5003xd72m8s1321iu',23,NULL,'🔥 Świeża okazja','Sitaniec apartament • 380000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-01 11:27:04.087',NULL,NULL,NULL,NULL,0,'2026-05-01 11:27:02.273','2026-05-01 11:27:04.089'),
('cmomtx5vf0043d72mn9z4qby3',3,NULL,'🎯 Właśnie wpadła','Wspaniały apartament w Łania • 404300 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:28:18.181','NO_ACTIVE_DEVICES',0,'2026-05-01 11:28:18.172','2026-05-06 07:43:17.079'),
('cmomtyawo0045d72mh4so6j2f',3,NULL,'🎯 Właśnie wpadła','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:29:11.362','NO_ACTIVE_DEVICES',0,'2026-05-01 11:29:11.352','2026-05-06 07:43:17.079'),
('cmomtyax70047d72m1isf5fk0',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-01 11:29:11.381','NO_ACTIVE_DEVICES',0,'2026-05-01 11:29:11.372','2026-05-01 11:29:11.382'),
('cmomtyj0p0049d72mg6l6e3at',3,NULL,'🎯 Właśnie wpadła','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,NULL,NULL,'2026-05-06 07:43:17.078','2026-05-01 11:29:21.876','NO_ACTIVE_DEVICES',0,'2026-05-01 11:29:21.865','2026-05-06 07:43:17.079'),
('cmomtyj1b004bd72mvlcc8wvv',24,NULL,'🔥 Świeża okazja','Ładnie mieszkanie na Wilanowie • 959000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-01 11:29:21.896','NO_ACTIVE_DEVICES',0,'2026-05-01 11:29:21.888','2026-05-01 11:29:21.897'),
('cmoorrlvs0021igp26n6dnh1l',24,NULL,'🔥 Świeża okazja','Luksusowy apartament z widokiem na stare miasto • 949000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 20:03:32.123','NO_ACTIVE_DEVICES',0,'2026-05-02 20:03:32.105','2026-05-02 20:03:32.124'),
('cmoos0wth0028igp2de2a9vry',3,NULL,'💎 Idealne trafienie','Luksusowa nieruchomość wsi tańcu • 400000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-05-02 20:10:48.085',NULL,'2026-05-06 07:42:50.101',NULL,NULL,0,'2026-05-02 20:10:46.181','2026-05-06 07:42:50.103'),
('cmoos0yan002aigp2s5xc9y0l',23,NULL,'🔥 Świeża okazja','Luksusowa nieruchomość wsi tańcu • 400000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-02 20:10:49.672',NULL,NULL,NULL,NULL,0,'2026-05-02 20:10:48.095','2026-05-02 20:10:49.673'),
('cmovxmlxn003ttsggoyndjvq1',23,NULL,'💎 Idealne trafienie','Bardzo ładny apartament na wynajem zielona okolica • 3800 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-07 20:22:01.957',NULL,NULL,NULL,NULL,0,'2026-05-07 20:21:59.819','2026-05-07 20:22:01.959'),
('cmozrrehu0003y1mmo6iu8cvw',23,NULL,'🔥 Świeża okazja','Piękny apartament • 800000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-10 12:48:52.043',NULL,NULL,NULL,NULL,0,'2026-05-10 12:48:50.467','2026-05-10 12:48:52.044'),
('cmozrrfq70005y1mmhme130m5',24,NULL,'🔥 Świeża okazja','Piękny apartament • 800000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-10 12:48:52.075','NO_ACTIVE_DEVICES',0,'2026-05-10 12:48:52.063','2026-05-10 12:48:52.078'),
('cmozrtxi3000by1mmyof5yskr',23,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-10 12:50:50.026',NULL,NULL,NULL,NULL,0,'2026-05-10 12:50:48.411','2026-05-10 12:50:50.028'),
('cmozrtyre000dy1mmrxfnab8c',24,NULL,'🔥 Świeża okazja','Mieszkanie Kawalerka Modlinska • 545000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-10 12:50:50.056','NO_ACTIVE_DEVICES',0,'2026-05-10 12:50:50.043','2026-05-10 12:50:50.059'),
('cmp22o89v000sg3u9l4jphoe2',38,NULL,'🎯 Właśnie wpadła','Świetna nieruchomość w Kalwarii • 850000 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-05-12 03:29:52.632',NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 03:29:50.564','2026-05-12 12:38:45.709'),
('cmp25tt87000a11jurzt707u4',3,NULL,'🎯 Właśnie wpadła','Mieszkanie w Berlinie tanio • 800000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-12 04:58:11.674',NULL,NULL,NULL,NULL,0,'2026-05-12 04:58:09.847','2026-05-12 04:58:11.675'),
('cmp27uti2000187svf36mhpjc',3,NULL,'🎯 Właśnie wpadła','Praga bsjsvsks • 903200 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-12 05:54:57.968',NULL,NULL,NULL,NULL,0,'2026-05-12 05:54:56.090','2026-05-12 05:54:57.970'),
('cmp27uuyh000387svb57aqeew',23,NULL,'🔥 Świeża okazja','Praga bsjsvsks • 903200 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-12 05:54:59.571',NULL,NULL,NULL,NULL,0,'2026-05-12 05:54:57.977','2026-05-12 05:54:59.573'),
('cmp27uw70000587svrp26af99',24,NULL,'🔥 Świeża okazja','Praga bsjsvsks • 903200 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-12 05:54:59.595','NO_ACTIVE_DEVICES',0,'2026-05-12 05:54:59.581','2026-05-12 05:54:59.597'),
('cmp296ce2000p87sv5tn24yyx',23,NULL,'🔥 Świeża okazja','Pięknie mieszkanie  • 600000 PLN','AI_RADAR','NORMAL','STANDARD','SENT',NULL,NULL,NULL,'2026-05-12 06:31:55.138',NULL,NULL,NULL,NULL,0,'2026-05-12 06:31:53.402','2026-05-12 06:31:55.139'),
('cmp296dqn000r87svbgav1ect',24,NULL,'🔥 Świeża okazja','Pięknie mieszkanie  • 600000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-12 06:31:55.162','NO_ACTIVE_DEVICES',0,'2026-05-12 06:31:55.151','2026-05-12 06:31:55.165'),
('cmp29cz0n001287sv9w2lnzud',3,'deal_event:deal:1:bid:1:PROPOSED','Nowa propozycja ceny','Nowa oferta: 849 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:37:02.663','2026-05-12 06:37:02.663'),
('cmp29ee48001587svlrnfv6cd',23,'deal_event:deal:1:bid:2:COUNTERED','Nowa kontroferta ceny','849 500 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:38:08.889','2026-05-12 06:38:08.889'),
('cmp29eold001887svt087ansx',3,'deal_event:deal:1:bid:3:COUNTERED','Nowa kontroferta ceny','849 500 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:38:22.465','2026-05-12 06:38:22.465'),
('cmp29g8bi001b87svkm66cdn2',23,'deal_event:deal:1:bid:4:COUNTERED','Nowa kontroferta ceny','860 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:39:34.686','2026-05-12 06:39:34.686'),
('cmp29gyiv001e87svs60oyown',3,'deal_event:deal:1:bid:5:COUNTERED','Nowa kontroferta ceny','860 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:40:08.647','2026-05-12 06:40:08.647'),
('cmp29n1uo001h87svlbk9vio8',23,'deal_event:deal:1:bid:6:COUNTERED','Nowa kontroferta ceny','860 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:44:52.896','2026-05-12 06:44:52.896'),
('cmp29ocmm001j87svjl39rlmd',23,'deal_msg:deal:1:msg:7','Nowa wiadomość w Dealroom','[[deal_attachment]]{\"url\":\"/uploads/offers/152/attachments/umowa_najmu_lokalu_uzytkowego_1to1-1778568353439-5953.docx\",\"','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:45:53.518','2026-05-12 06:45:53.518'),
('cmp29phqx001m87sv175nfbdl',3,'deal_event:deal:1:bid:7:COUNTERED','Nowa kontroferta ceny','849 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:46:46.809','2026-05-12 06:46:46.809'),
('cmp29pu2l001p87sv630z6ja3',23,'deal_event:deal:1:bid:8:COUNTERED','Nowa kontroferta ceny','849 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 06:47:02.781','2026-05-12 06:47:02.781'),
('cmp2gjf7j003687sv5vudu08v',38,NULL,'🎯 Właśnie wpadła','Koziennice tower • 806600 PLN','AI_RADAR','NORMAL','STANDARD','READ',NULL,NULL,NULL,'2026-05-12 09:58:02.658',NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 09:58:00.895','2026-05-12 12:38:45.709'),
('cmp2h2482003k87svq3hff7sg',3,'deal_msg:deal:3:msg:10','Nowa wiadomość w Dealroom','Mój kochany najfajniejszy mąż','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','3',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 10:12:33.122','2026-05-12 10:12:33.122'),
('cmp2h2k51003m87svkin7n65q',23,'deal_msg:deal:3:msg:11','Nowa wiadomość w Dealroom',':*','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','3',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 10:12:53.749','2026-05-12 10:12:53.749'),
('cmp2i75ha003r87svveh5nb8h',38,'deal_msg:deal:2:msg:12','Nowa wiadomość w Dealroom','Hej','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','2',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 10:44:27.646','2026-05-12 12:38:45.709'),
('cmp2i7ubx003t87svysmussvv',38,'deal_msg:deal:2:msg:13','Nowa wiadomość w Dealroom','Hg','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','2',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 10:44:59.853','2026-05-12 12:38:45.709'),
('cmp2idkkr003v87sv9y86apke',38,'deal_event:deal:5:bid:9:PROPOSED','Nowa propozycja ceny','Nowa oferta: 880 000 PLN','BID_RECEIVED','NORMAL','STANDARD','READ',NULL,'DEAL','5',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 10:49:27.147','2026-05-12 12:38:45.709'),
('cmp2in03k004187svcrd1io41',3,'deal_event:deal:5:bid:10:COUNTERED','Nowa kontroferta ceny','875 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','5',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 10:56:47.168','2026-05-12 10:56:47.168'),
('cmp2io6vv004487sv366j1b90',38,'deal_event:deal:5:bid:11:COUNTERED','Nowa kontroferta ceny','875 000 PLN','BID_RECEIVED','NORMAL','STANDARD','READ',NULL,'DEAL','5',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 10:57:42.620','2026-05-12 12:38:45.709'),
('cmp2iqwy7004787svyyh9rxoc',3,'deal_event:deal:5:bid:11:ACCEPTED','Twoja oferta zostala zaakceptowana','875 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','5',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 10:59:49.711','2026-05-12 10:59:49.711'),
('cmp2j6z8s004987svkymbrq52',3,'deal_msg:deal:2:msg:18','Nowa wiadomość w Dealroom','Bvv','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','2',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:12:19.180','2026-05-12 11:12:19.180'),
('cmp2j9sfo004b87svkkno15z0',3,'deal_msg:deal:3:msg:19','Nowa wiadomość w Dealroom','Mój kochany najfajniejszy mąż❤️','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','3',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:14:30.324','2026-05-12 11:14:30.324'),
('cmp2j9y3v004d87svad9a7h55',23,'deal_event:deal:6:bid:12:PROPOSED','Nowa propozycja ceny','Nowa oferta: 760 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:14:37.675','2026-05-12 11:14:37.675'),
('cmp2jacvj004g87svea18j8e8',38,'deal_event:deal:6:bid:13:COUNTERED','Nowa kontroferta ceny','761 000 PLN','BID_RECEIVED','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:14:56.815','2026-05-12 12:38:45.709'),
('cmp2jbmrk000258dyl79pq8wq',23,'deal_event:deal:6:bid:14:COUNTERED','Nowa kontroferta ceny','756 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:15:56.288','2026-05-12 11:15:56.288'),
('cmp2jcg52000458dyjssz9bur',23,'deal_msg:deal:6:msg:23','Nowa wiadomość w Dealroom','🐿️','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:16:34.358','2026-05-12 11:16:34.358'),
('cmp2jd2zy000658dylevx1tew',39,NULL,'Oferta niedostępna','Nieruchomość została sprzedana innemu klientowi.','SYSTEM_ALERT','NORMAL','STANDARD','PENDING',NULL,'DEAL','4',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:03.982','2026-05-12 11:17:03.982'),
('cmp2jd30w000858dy234v6hnr',3,'deal_event:deal:7:bid:15:ACCEPTED','Twoja oferta zostala zaakceptowana','500 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:04.016','2026-05-12 11:17:04.016'),
('cmp2jd5lw000b58dyciuv0km0',38,'deal_event:deal:6:bid:16:COUNTERED','Nowa kontroferta ceny','757 000 PLN','BID_RECEIVED','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:17:07.364','2026-05-12 12:38:45.709'),
('cmp2jdchb000d58dyjzwueg6a',38,'deal_msg:deal:6:msg:27','Nowa wiadomość w Dealroom','🙂','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:17:16.271','2026-05-12 12:38:45.709'),
('cmp2jdebo000g58dyejqz2vy3',24,'deal_event:deal:7:bid:18:COUNTERED','Nowa kontroferta ceny','850 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:18.660','2026-05-12 11:17:18.660'),
('cmp2jdmcf000j58dy6rjqlw7m',3,'deal_event:deal:7:bid:19:REJECTED','Twoja oferta zostala odrzucona','500 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:29.055','2026-05-12 11:17:29.055'),
('cmp2jdviy000m58dyz8dqdlwu',23,'deal_event:deal:6:bid:20:COUNTERED','Nowa kontroferta ceny','757 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:40.954','2026-05-12 11:17:40.954'),
('cmp2jdxhz000o58dypzlj76fd',39,NULL,'Oferta niedostępna','Nieruchomość została sprzedana innemu klientowi.','SYSTEM_ALERT','NORMAL','STANDARD','PENDING',NULL,'DEAL','4',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:43.512','2026-05-12 11:17:43.512'),
('cmp2jdxik000q58dyk5igwli1',3,'deal_event:deal:7:bid:21:ACCEPTED','Twoja oferta zostala zaakceptowana','500 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:17:43.532','2026-05-12 11:17:43.532'),
('cmp2jgzrj000s58dytxxcoqez',3,'deal_review:deal:5:reviewer:38:target:3','Otrzymano ocenę kontrahenta','Kliknij, aby przejść do transakcji i dodać swoją opinię.','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','5',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:20:06.415','2026-05-12 11:20:06.415'),
('cmp2jhslt000u58dyr4q90hxf',38,'deal_review:deal:5:reviewer:3:target:38','Otrzymano ocenę kontrahenta','Kliknij, aby przejść do transakcji i dodać swoją opinię.','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','5',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:20:43.793','2026-05-12 12:38:45.709'),
('cmp2jn2b600018is25x6vc2hq',39,NULL,'Oferta niedostępna','Nieruchomość została sprzedana innemu klientowi.','SYSTEM_ALERT','NORMAL','STANDARD','PENDING',NULL,'DEAL','4',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:24:49.650','2026-05-12 11:24:49.650'),
('cmp2jn2c400038is2sg75mxzk',3,'deal_event:deal:7:bid:22:ACCEPTED','Twoja oferta zostala zaakceptowana','500 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:24:49.684','2026-05-12 11:24:49.684'),
('cmp2jnjav00058is2qootkdo3',39,NULL,'Oferta niedostępna','Nieruchomość została sprzedana innemu klientowi.','SYSTEM_ALERT','NORMAL','STANDARD','PENDING',NULL,'DEAL','4',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:25:11.671','2026-05-12 11:25:11.671'),
('cmp2jnjba00078is2j84tludj',3,NULL,'✅ Oferta zaakceptowana','Twoja oferta 600000 PLN została przyjęta.','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','7',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:25:11.686','2026-05-12 11:25:11.686'),
('cmp2jpqx500098is2cprd0b62',38,'deal_msg:deal:6:msg:37','Nowa wiadomość w Dealroom','Możemy tak pisać bez końca 🙂','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:26:54.857','2026-05-12 12:38:45.709'),
('cmp2jpxya000c8is2vg25twpa',38,'deal_event:deal:6:bid:24:COUNTERED','Nowa kontroferta ceny','757 000 PLN','BID_RECEIVED','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:27:03.970','2026-05-12 12:38:45.709'),
('cmp2jqfl8000e8is2t7qpx3h9',23,'deal_msg:deal:6:msg:39','Nowa wiadomość w Dealroom','Misia jeśli u ciebie pluka cały czas coś to to nie ja piszę tylko serwer się naprawia','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:27:26.828','2026-05-12 11:27:26.828'),
('cmp2jquhs000g8is2wpahxikc',38,'deal_msg:deal:6:msg:40','Nowa wiadomość w Dealroom','Negocjacje','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:27:46.144','2026-05-12 12:38:45.709'),
('cmp2jqx0r000i8is2izmw28vj',23,'deal_msg:deal:6:msg:41','Nowa wiadomość w Dealroom','Na jakieś pół godzinki po prostu nie zwracaj uwagi','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:27:49.420','2026-05-12 11:27:49.420'),
('cmp2jr0pe000k8is2nhxesrcp',38,'deal_msg:deal:6:msg:42','Nowa wiadomość w Dealroom','Już zaakceptowałam','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:27:54.194','2026-05-12 12:38:45.709'),
('cmp2jr4l7000m8is24deyov16',23,'deal_msg:deal:6:msg:43','Nowa wiadomość w Dealroom','Dokładnie serwer zamyka zaległości','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:27:59.227','2026-05-12 11:27:59.227'),
('cmp2jru0c000o8is27wqpf2y6',38,'deal_msg:deal:6:msg:44','Nowa wiadomość w Dealroom','🙂','DEAL_UPDATE','NORMAL','STANDARD','READ',NULL,'DEAL','6',NULL,NULL,'2026-05-12 12:38:45.707',NULL,NULL,0,'2026-05-12 11:28:32.172','2026-05-12 12:38:45.709'),
('cmp2jrwwc000r8is2yq4z9rt0',23,'deal_event:deal:6:bid:25:COUNTERED','Nowa kontroferta ceny','757 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 11:28:35.916','2026-05-12 11:28:35.916'),
('cmp2mak5m001l8is2bvrqq4q2',23,NULL,'❌ Oferta odrzucona','Twoja oferta 757000 PLN została odrzucona.','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 12:39:05.098','2026-05-12 12:39:05.098'),
('cmp2nrchf00045dx59zq3kqeo',39,'deal_event:deal:9:appointment:1:PROPOSED','Nowa propozycja terminu','13.05.2026, 13:00:00','APPOINTMENT','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:20:07.924','2026-05-12 13:20:07.924'),
('cmp2nrtyg00075dx5qnz3wg7y',3,'deal_event:deal:9:appointment:2:COUNTERED','Nowa kontroferta terminu','14.05.2026, 14:00:00','APPOINTMENT','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:20:30.568','2026-05-12 13:20:30.568'),
('cmp2ns1mj000a5dx5yqn39f4o',39,'deal_event:deal:9:appointment:2:ACCEPTED','Termin zostal zaakceptowany','14.05.2026, 14:00:00','APPOINTMENT','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:20:40.507','2026-05-12 13:20:40.507'),
('cmp2ntzgx000c5dx58kxkupg0',39,'deal_event:deal:9:bid:26:PROPOSED','Nowa propozycja ceny','Nowa oferta: 806 600 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:22:11.025','2026-05-12 13:22:11.025'),
('cmp2nuj1o000f5dx55neu7alc',3,'deal_event:deal:9:bid:27:COUNTERED','Nowa kontroferta ceny','821 600 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:22:36.396','2026-05-12 13:22:36.396'),
('cmp2nurqd000i5dx5gdqdy5ra',39,'deal_event:deal:9:bid:28:COUNTERED','Nowa kontroferta ceny','821 600 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:22:47.653','2026-05-12 13:22:47.653'),
('cmp2o1g6x000l5dx50d61b0qa',3,'deal_event:deal:9:bid:28:ACCEPTED','Twoja oferta zostala zaakceptowana','821 600 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:27:59.289','2026-05-12 13:27:59.289'),
('cmp2o1k9n000n5dx5e0xcg58g',3,'deal_msg:deal:9:msg:54','Nowa wiadomość w Dealroom','Decyzja właściciela: ostatecznie akceptuję cenę 821 600 PLN i zamykam sprzedaż. Oferta została wycofana z rynku.','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','9',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 13:28:04.572','2026-05-12 13:28:04.572'),
('cmp2x2xu40014xwayg5smaw5n',24,NULL,'🔥 Świeża okazja','Hcyxcuvh uvuchcivy  • 500000 PLN','AI_RADAR','NORMAL','STANDARD','FAILED',NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-12 17:41:05.377','NO_ACTIVE_DEVICES',0,'2026-05-12 17:41:05.356','2026-05-12 17:41:05.379'),
('cmp30stu6000o3hj8f0bh68io',3,'deal_event:deal:1:bid:29:COUNTERED','Nowa kontroferta ceny','849 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','1',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 19:25:12.078','2026-05-12 19:25:12.078'),
('cmp39zzv5000feiimgmjtztwf',3,NULL,'Nowa wiadomość w Dealroom','Jvvv vbb','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','2',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 23:42:43.025','2026-05-12 23:42:43.025'),
('cmp3a72p5000heiimem0j7r64',23,NULL,'💎 Nowa Oferta Zakupu!','Kupiec złożył oficjalną ofertę w kwocie 800 000 PLN (Gotówka) za Twoją nieruchomość. Wejdź w Lejek CRM.','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 23:48:13.289','2026-05-12 23:48:13.289'),
('cmp3a7g8v000jeiimxtn9ikwe',23,NULL,'Nowe zapytanie z Lejka!','Klient chce obejrzeć Twoją nieruchomość.','APPOINTMENT','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 23:48:30.848','2026-05-12 23:48:30.848'),
('cmp3aeedh000oeiimf4eo2d5h',23,NULL,'Nowa wiadomość w Dealroom','📎 IMG_5362.png','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-12 23:53:55.013','2026-05-12 23:53:55.013'),
('cmp3sphdq000teiim3yn5ju5j',23,'deal_msg:deal:6:msg:60','Nowa wiadomość w Dealroom','Misia 🐻','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:26:25.214','2026-05-13 08:26:25.214'),
('cmp3sqtgc0010eiiml837dsk2',23,'deal_event:deal:6:bid:31:PROPOSED','Nowa propozycja ceny','Nowa oferta: 795 000 PLN','BID_RECEIVED','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:27:27.516','2026-05-13 08:27:27.516'),
('cmp3srdpq0012eiimx6ot0otf',38,'deal_msg:deal:6:msg:62','Nowa wiadomość w Dealroom','😍','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:27:53.775','2026-05-13 08:27:53.775'),
('cmp3srico0015eiimskyp4m4m',38,'deal_event:deal:6:appointment:3:ACCEPTED','Termin zostal zaakceptowany','14.05.2026, 14:00:00','APPOINTMENT','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:27:59.784','2026-05-13 08:27:59.784'),
('cmp3ssgjp0017eiimbo49abcu',38,'deal_msg:deal:6:msg:64','Nowa wiadomość w Dealroom','Zapisało w kalendarzu 😃','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:28:44.101','2026-05-13 08:28:44.101'),
('cmp3ssm8w0019eiim8b5h1d4m',23,'deal_msg:deal:6:msg:65','Nowa wiadomość w Dealroom',':*','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:28:51.488','2026-05-13 08:28:51.488'),
('cmp3stbee001beiim19gowcuc',38,'deal_msg:deal:6:msg:66','Nowa wiadomość w Dealroom','❤️','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:29:24.086','2026-05-13 08:29:24.086'),
('cmp3suhpi001deiimqc3ig3a1',23,'deal_msg:deal:6:msg:67','Nowa wiadomość w Dealroom','Misia wyślesz mi kontrofertę?','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:30:18.919','2026-05-13 08:30:18.919'),
('cmp3suqad001feiimcjslz3qk',23,'deal_msg:deal:6:msg:68','Nowa wiadomość w Dealroom','I czy ty masz najnowszą wersję czy Widzisz ten zegarek?','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:30:30.037','2026-05-13 08:30:30.037'),
('cmp3svadh001heiim8syw2ale',38,'deal_msg:deal:6:msg:69','Nowa wiadomość w Dealroom','Tak','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:30:56.069','2026-05-13 08:30:56.069'),
('cmp3svbwq001jeiimbryj3srw',38,'deal_msg:deal:6:msg:70','Nowa wiadomość w Dealroom','Widzę','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:30:58.058','2026-05-13 08:30:58.058'),
('cmp3sx6ha001leiim7gvob97l',23,'deal_msg:deal:6:msg:71','Nowa wiadomość w Dealroom','Zaakceptujesz cenę?','DEAL_UPDATE','NORMAL','STANDARD','PENDING',NULL,'DEAL','6',NULL,NULL,NULL,NULL,NULL,0,'2026-05-13 08:32:24.334','2026-05-13 08:32:24.334');
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `NotificationPreference`
--

DROP TABLE IF EXISTS `NotificationPreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `NotificationPreference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` enum('MESSAGE','DEAL_UPDATE','BID_RECEIVED','APPOINTMENT','SYSTEM_ALERT','AI_RADAR','MARKETING') NOT NULL,
  `pushEnabled` tinyint(1) NOT NULL DEFAULT 1,
  `emailEnabled` tinyint(1) NOT NULL DEFAULT 1,
  `inAppEnabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `NotificationPreference_userId_type_key` (`userId`,`type`),
  CONSTRAINT `NotificationPreference_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotificationPreference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `NotificationPreference` WRITE;
/*!40000 ALTER TABLE `NotificationPreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotificationPreference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Offer`
--

DROP TABLE IF EXISTS `Offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `transactionType` enum('SELL','RENT') NOT NULL DEFAULT 'SELL',
  `propertyType` enum('FLAT','HOUSE','PLOT','COMMERCIAL') NOT NULL DEFAULT 'FLAT',
  `condition` enum('READY','NEEDS_RENOVATION','DEVELOPER_STATE','NOT_APPLICABLE') NOT NULL DEFAULT 'READY',
  `price` double NOT NULL,
  `pricePerSqm` double DEFAULT NULL,
  `adminFee` double DEFAULT NULL,
  `deposit` double DEFAULT NULL,
  `area` double NOT NULL,
  `plotArea` double DEFAULT NULL,
  `rooms` int(11) DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `totalFloors` int(11) DEFAULT NULL,
  `yearBuilt` int(11) DEFAULT NULL,
  `hasBalcony` tinyint(1) NOT NULL DEFAULT 0,
  `hasElevator` tinyint(1) NOT NULL DEFAULT 0,
  `hasStorage` tinyint(1) NOT NULL DEFAULT 0,
  `hasParking` tinyint(1) NOT NULL DEFAULT 0,
  `hasGarden` tinyint(1) NOT NULL DEFAULT 0,
  `isFurnished` tinyint(1) NOT NULL DEFAULT 0,
  `city` varchar(191) NOT NULL DEFAULT 'Warszawa',
  `district` varchar(191) NOT NULL DEFAULT 'OTHER',
  `street` varchar(191) DEFAULT NULL,
  `buildingNumber` varchar(191) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `isExactLocation` tinyint(1) NOT NULL DEFAULT 1,
  `agentCommissionPercent` double DEFAULT NULL,
  `images` text DEFAULT NULL,
  `videoUrl` varchar(191) DEFAULT NULL,
  `floorPlanUrl` varchar(191) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','REJECTED','ARCHIVED','SOLD','IN_DEAL') NOT NULL DEFAULT 'ACTIVE',
  `expiresAt` datetime(3) DEFAULT NULL,
  `promotedUntil` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `userId` int(11) NOT NULL,
  `heating` varchar(191) DEFAULT NULL,
  `archivedAt` datetime(3) DEFAULT NULL,
  `soldAt` datetime(3) DEFAULT NULL,
  `archiveReason` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Offer_userId_fkey` (`userId`),
  CONSTRAINT `Offer_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Offer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Offer` WRITE;
/*!40000 ALTER TABLE `Offer` DISABLE KEYS */;
INSERT INTO `Offer` VALUES
(73,'Testowa oferta','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 2\n🏢 Piętro: 3\n💶 Czynsz adm.: 555 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',666666,NULL,NULL,NULL,55,NULL,2,NULL,NULL,NULL,0,0,0,0,0,0,'Warszawa','Śródmieście',NULL,NULL,52.2332,21.0184,1,NULL,'[\"/uploads/offer_73/photo-1776979341982-4111.jpg\",\"/uploads/offer_73/photo-1776979347982-1424.jpg\"]',NULL,'/uploads/offer_73/floorplan-1776979348890-385.jpg','ARCHIVED',NULL,NULL,'2026-04-23 21:22:14.298','2026-04-24 11:41:38.043',3,NULL,'2026-04-24 11:41:38.043',NULL,NULL),
(82,'Łódź Bogu jhbhj inni m ','Przekrocz próg przestrzeni, która redefiniuje pojęcie luksusu i komfortu.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Łódź. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 33 m²\n🛏 Pokoje: 3\n🏢 Piętro: 1\n💶 Czynsz adm.: 666 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',777777,NULL,NULL,NULL,33,NULL,3,NULL,NULL,NULL,0,0,0,0,0,0,'Łódź','Bałuty',NULL,NULL,51.7999638,19.4233758,1,NULL,'[\"/uploads/offer_82/photo-1777007407195-8951.jpg\",\"/uploads/offer_82/photo-1777007412099-7250.jpg\",\"/uploads/offer_82/photo-1777007414617-8834.jpg\",\"/uploads/offer_82/photo-1777007419348-387.jpg\"]',NULL,'/uploads/offer_82/floorplan-1777007419896-4337.jpg','ARCHIVED',NULL,NULL,'2026-04-24 05:10:01.577','2026-04-25 19:44:13.654',3,NULL,'2026-04-25 19:44:13.654',NULL,NULL),
(85,'Uvufycvy u','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Wrocław. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nZaledwie 3 minuty spacerem do głównych węzłów komunikacyjnych.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 58 m²\n🛏 Pokoje: 2\n🏢 Piętro: 3\n💶 Czynsz adm.: 585 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',555555,NULL,NULL,NULL,58,NULL,2,NULL,NULL,NULL,0,0,0,0,0,0,'Wrocław','Psie Pole',NULL,NULL,51.14449937116557,17.10829010527912,1,NULL,'[\"/uploads/offer_85/photo-1777016297780-1776.jpg\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-24 07:38:17.000','2026-04-24 11:41:34.324',3,NULL,'2026-04-24 11:41:34.324',NULL,NULL),
(86,'No big hi hi  g','Przekrocz próg przestrzeni, która redefiniuje pojęcie luksusu i komfortu.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Wrocław. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 1\n🏢','SELL','FLAT','READY',999999,NULL,NULL,NULL,55,NULL,1,NULL,NULL,NULL,0,0,0,0,0,0,'Wrocław','Psie Pole',NULL,NULL,51.14395423236612,17.10806135788878,1,NULL,'[\"/uploads/offer_86/photo-1777016948697-876.jpg\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-24 07:49:07.677','2026-04-24 11:41:33.365',3,NULL,'2026-04-24 11:41:33.365',NULL,NULL),
(88,'Ofjgvhcvjgcjg','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Łódź. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 77 m²\n\nZapraszamy','SELL','FLAT','READY',333333,NULL,NULL,NULL,77,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,'Łódź','Polesie',NULL,NULL,51.75959124345935,19.4574578333662,1,NULL,'[]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-24 08:21:07.198','2026-05-10 10:43:40.940',3,NULL,'2026-05-10 10:43:40.940',NULL,NULL),
(89,'Ofjgvhcvjgcjg','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Łódź. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 77 m²\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',333333,NULL,NULL,NULL,77,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,'Łódź','Polesie',NULL,NULL,51.75959124345935,19.4574578333662,1,NULL,'[]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-24 08:21:35.407','2026-04-24 11:41:31.508',3,NULL,'2026-04-24 11:41:31.508',NULL,NULL),
(93,'Cchjvjgcjgvkhchgo','Przekrocz próg przestrzeni, która redefiniuje pojęcie luksusu i komfortu.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 77 m²\n🛏 Pokoje: 1\n🏢 Piętro: 1\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',888888,NULL,NULL,NULL,77,NULL,1,NULL,NULL,NULL,0,0,0,0,0,0,'Warszawa','Śródmieście',NULL,NULL,52.23036464398418,21.01204712921351,1,NULL,'[\"/uploads/offers/93/e4d920be-cf10-4b90-a29f-d440764202ed.webp\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-24 09:51:30.620','2026-04-24 11:41:25.844',3,NULL,'2026-04-24 11:41:25.844',NULL,NULL),
(94,'Luksusowy apartament na Mokotowie','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 2\n🏢 Piętro: 1\n💶 Czynsz adm.: 800 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',899000,NULL,NULL,NULL,55,NULL,2,NULL,NULL,NULL,0,0,0,0,0,0,'Warszawa','Mokotów',NULL,NULL,52.19374566732601,21.02709105435928,1,NULL,'[\"/uploads/offer_94/photo-1777031094453-147.jpg\",\"/uploads/offer_94/photo-1777031098112-3170.jpg\",\"/uploads/offer_94/photo-1777031101491-7880.jpg\",\"/uploads/offer_94/photo-1777031104029-8094.jpg\",\"/uploads/offer_94/photo-1777031106933-975.jpg\"]',NULL,'/uploads/offer_94/floorplan-1777031108211-1336.jpg','ARCHIVED',NULL,NULL,'2026-04-24 11:44:51.305','2026-05-10 10:43:40.758',3,NULL,'2026-05-10 10:43:40.758',NULL,NULL),
(105,'Bvhvjjkkbb','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia,','SELL','FLAT','READY',588566,NULL,NULL,NULL,88,NULL,2,1,NULL,2021,1,0,1,1,0,0,'Warszawa','Mokotów',NULL,NULL,52.19371205589434,21.02799797683858,1,NULL,'[\"/uploads/offer_105/photo-1777054816969-2417.jpg\"]',NULL,'/uploads/offer_105/floorplan-1777054817789-7388.jpg','ARCHIVED','2026-05-30 23:39:11.466',NULL,'2026-04-24 18:20:15.084','2026-05-10 10:43:40.578',3,NULL,'2026-05-10 10:43:40.578',NULL,NULL),
(106,'Luksusowy apartament z widokiem na stare miasto','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Kraków. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nZaledwie 3 minuty spacerem do głównych węzłów komunikacyjnych.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 53 m²\n🛏 Pokoje: 3\n🏢 Piętro: 3\n💶 Czynsz adm.: 600 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',949000,NULL,NULL,NULL,53,NULL,3,3,NULL,1953,1,1,1,1,1,1,'Warszawa','Mokotów',NULL,NULL,50.06140144444128,19.93659999999997,1,NULL,'[\"/uploads/offer_106/photo-1777110111561-5306.jpg\",\"/uploads/offer_106/photo-1777110116346-461.jpg\",\"/uploads/offer_106/photo-1777110118823-77.jpg\",\"/uploads/offer_106/photo-1777110120385-5202.jpg\"]',NULL,'/uploads/offer_106/floorplan-1777110120866-6424.jpg','ARCHIVED',NULL,NULL,'2026-04-25 09:41:46.444','2026-05-10 10:43:40.242',3,NULL,'2026-05-10 10:43:40.242',NULL,NULL),
(107,'Świetna oferta we Wrocławiu','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Wrocław. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 33 m²\n🛏 Pokoje: 3\n🏢 Piętro: Parter\n💶 Czynsz adm.: 433 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',777777,NULL,NULL,NULL,33,NULL,3,NULL,NULL,2020,0,1,1,1,1,1,'Wrocław','Psie Pole',NULL,NULL,51.14446490321411,17.10774459132531,1,NULL,'[]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-25 13:24:39.887','2026-05-10 10:43:39.908',3,NULL,'2026-05-10 10:43:39.908',NULL,NULL),
(108,'Świetna oferta we Wrocławiu','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Wrocław. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 33 m²\n🛏 Pokoje: 3\n🏢 Piętro: Parter\n💶 Czynsz adm.: 433 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',777777,NULL,NULL,NULL,33,NULL,3,NULL,NULL,2020,0,1,1,1,1,1,'Wrocław','Psie Pole',NULL,NULL,51.14446490321411,17.10774459132531,1,NULL,'[\"/uploads/offer_108/photo-1777123506849-132.jpg\",\"/uploads/offer_108/photo-1777123508269-4694.jpg\"]',NULL,'/uploads/offer_108/floorplan-1777123508918-6037.jpg','ARCHIVED',NULL,NULL,'2026-04-25 13:25:05.371','2026-05-10 10:43:39.572',3,NULL,'2026-05-10 10:43:39.572',NULL,NULL),
(109,'Świetna nieruchomość na Białołęce','Przekrocz próg przestrzeni, która redefiniuje pojęcie luksusu i komfortu.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 66 m²\n🛏 Pokoje: 3\n🏢 Piętro: 3\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',489000,NULL,NULL,NULL,66,NULL,3,3,NULL,2014,1,1,0,0,0,1,'Warszawa','Białołęka',NULL,NULL,52.32382256418607,20.96917270367167,1,NULL,'[\"/uploads/offer_109/photo-1777144441088-4675.jpg\",\"/uploads/offer_109/photo-1777144442909-2328.jpg\",\"/uploads/offer_109/photo-1777144444734-3060.jpg\",\"/uploads/offer_109/photo-1777144446554-8518.jpg\"]',NULL,'/uploads/offer_109/floorplan-1777144447166-6564.jpg','ARCHIVED',NULL,NULL,'2026-04-25 19:13:59.030','2026-05-10 10:43:39.408',3,NULL,'2026-05-10 10:43:39.408',NULL,NULL),
(110,'Przestronny dom .&&3€;€3€:?3?','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy dom na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 3\n🏢 Piętro: 2\n💶 Czynsz adm.: 1500 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','HOUSE','READY',750000,NULL,NULL,NULL,55,NULL,3,2,NULL,2021,1,1,1,1,0,1,'Warszawa','Ursynów',NULL,NULL,52.14057304763396,21.05942329999999,1,NULL,'[\"/uploads/offer_110/photo-1777145100412-9374.jpg\",\"/uploads/offer_110/photo-1777145102196-9052.jpg\",\"/uploads/offer_110/photo-1777145103983-9359.jpg\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-04-25 19:24:59.458','2026-05-10 10:43:39.237',23,NULL,'2026-05-10 10:43:39.237',NULL,NULL),
(113,'Cudownej apartament w Sopocie','Adres, który zaczyna pracować od pierwszego dnia.\n\napartament w Sopot - Dolny.\n\nPowierzchnia: **55 m²**  \nCena: **850000 PLN**  \nUkład: **3 pokoi**\n\nMiejsce, które działa zarówno dla życia, jak i inwestycji.\n\n• dobra lokalizacja  \n• funkcjonalny układ  \n• potencjał inwestycyjny  \n\nTakie oferty nie czekają długo.','SELL','FLAT','READY',850000,NULL,NULL,NULL,55,NULL,3,2,NULL,1988,1,0,1,1,0,0,'Trójmiasto','Sopot - Dolny',NULL,NULL,54.44533338179731,18.56490532777412,1,NULL,'[\"/uploads/offer_113/photo-1777172416890-6938.jpg\",\"/uploads/offer_113/photo-1777172420741-5798.jpg\",\"/uploads/offer_113/photo-1777172424500-8813.jpg\",\"/uploads/offer_113/photo-1777172428408-9987.jpg\"]',NULL,'/uploads/offer_113/floorplan-1777172429101-6516.jpg','ARCHIVED',NULL,NULL,'2026-04-26 03:00:16.024','2026-05-10 10:43:38.587',3,NULL,'2026-05-10 10:43:38.587',NULL,NULL),
(114,'Piękny apartament','Tu decyzje podejmuje się szybko.\n\napartament w Mokotów.\n\nPowierzchnia: **80 m²**  \nCena: **800000 PLN**  \nUkład: **3 pokoi**\n\nUkład, który nie marnuje ani jednego metra.\n\n• dobra lokalizacja  \n• funkcjonalny układ  \n• potencjał inwestycyjny  \n\nDecyzje w tej lokalizacji zapadają szybko.','SELL','FLAT','READY',800000,NULL,NULL,NULL,80,NULL,3,NULL,NULL,2018,0,0,1,1,1,1,'Warszawa','Mokotów',NULL,NULL,52.20660611183563,21.02199999999998,1,NULL,'[\"/uploads/offer_114/photo-1777192310562-6978.jpg\",\"/uploads/offer_114/photo-1777192313791-2410.jpg\",\"/uploads/offer_114/photo-1777192317172-722.jpg\"]',NULL,NULL,'ACTIVE',NULL,NULL,'2026-04-26 08:31:49.983','2026-05-12 06:01:30.289',23,'Miejskie',NULL,NULL,NULL),
(116,'Mieszkanie Kawalerka Modlinska','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 30 m²\n🛏 Pokoje: 1\n🏢 Piętro: Parter\n💶 Czynsz adm.: 600 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',545000,NULL,NULL,NULL,30,NULL,1,NULL,NULL,NULL,1,0,0,0,1,1,'Warszawa','Białołęka','Modlińska 56B',NULL,52.3059013910893,20.98889999999999,1,NULL,'[\"/uploads/offer_116/photo-1777331737268-4212.jpg\"]',NULL,NULL,'ACTIVE',NULL,NULL,'2026-04-27 23:15:35.475','2026-05-12 11:25:11.658',24,NULL,NULL,NULL,NULL),
(124,'Wspaniały apartament w Łania','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Łabunie. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 33 m²\n🛏 Pokoje: 1\n🏢 Piętro: 2\n💶 Czynsz adm.: 500 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',350000,NULL,500,NULL,33,NULL,1,2,NULL,1981,1,0,0,1,0,0,'Łabunie','Łabunie','Osiedlowa 23',NULL,50.65095120493115,23.37461148920886,1,NULL,'[\"/uploads/offer_124/photo-1777409406216-7692.jpg\",\"/uploads/offer_124/photo-1777409408700-4883.jpg\",\"/uploads/offer_124/photo-1777409411492-2494.jpg\"]',NULL,'/uploads/offer_124/floorplan-1777409413796-2466.jpg','ARCHIVED',NULL,NULL,'2026-04-28 20:50:02.196','2026-05-10 10:43:36.306',3,NULL,'2026-05-10 10:43:36.306',NULL,NULL),
(141,'Perine mieszam','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Reszta kraju. Nieruchomość jest z potencjałem do remontu, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 50 m²\n🛏 Pokoje: 2\n🏢 Piętro: 2\n💶 Czynsz adm.: 500 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','NEEDS_RENOVATION',390000,NULL,500,NULL,50,NULL,2,2,NULL,2019,1,0,1,1,0,1,'Reszta kraju','Krasnobród','W Sikorskiego 53',NULL,50.54447554426486,23.20044539248369,1,NULL,'[\"/uploads/offers/141/6a5f4f9b-82cd-4868-867d-3c535749f228.webp\",\"/uploads/offers/141/45f995e2-53a4-4e01-9c66-8a795ae7f0da.webp\"]',NULL,'/uploads/offers/141/0f98219c-022e-439e-abcc-a195618eb34f.webp','REJECTED',NULL,NULL,'2026-05-03 07:57:35.617','2026-05-10 15:29:37.795',23,NULL,NULL,NULL,NULL),
(142,'Reu;jtdouuiydukhyfuid','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Kraków. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 4\n🏢 Piętro: 3\n💶 Czynsz adm.: 1100 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',685500,NULL,1100,NULL,55,NULL,4,3,NULL,2023,1,1,0,0,0,0,'Kraków','Prądnik Biały','Ks K Siemaszki 52',NULL,50.08767716694606,19.94004152730026,1,NULL,'[\"/uploads/offers/142/75a4a4bb-e818-4969-a2a1-6150c2b25b03.webp\",\"/uploads/offers/142/5af50ed7-675c-4e17-ba94-772e1c8eaea7.webp\",\"/uploads/offers/142/8866075f-1398-459a-889b-180f24c2c7c9.webp\"]',NULL,'/uploads/offers/142/f49c9923-edd1-4f8a-821a-229ce3c078eb.webp','REJECTED',NULL,NULL,'2026-05-04 17:18:08.489','2026-05-10 15:29:39.320',23,NULL,NULL,NULL,NULL),
(143,' Knvgjgo’fyff8oyj gong','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Reszta kraju. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 42 m²\n🛏 Pokoje: 2\n🏢 Piętro: Parter\n💶 Czynsz adm.: 660000 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','READY',482600,NULL,660000,NULL,42,NULL,2,0,NULL,2016,1,1,1,0,0,0,'Reszta kraju','Rawa Mazowiecka','Stefana Batorego 9',NULL,51.77529013982409,20.26250019999997,1,NULL,'[\"/uploads/offers/143/a3e1dfe4-5cd8-41de-b96a-d11a0fcedb3a.webp\",\"/uploads/offers/143/870a403e-6d69-496e-ba81-c1a986bc5279.webp\",\"/uploads/offers/143/08104e6e-941e-4421-8520-9ea339f9f28c.webp\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-05-04 17:23:22.831','2026-05-12 06:22:08.976',23,NULL,'2026-05-12 06:22:08.976',NULL,NULL),
(144,'Ihbjgvouhuhv8ynjkbOh','Przekrocz próg przestrzeni, która redefiniuje pojęcie luksusu i komfortu.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Reszta kraju. Nieruchomość jest z potencjałem do remontu, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nZaledwie 3 minuty spacerem do głównych węzłów komunikacyjnych.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 86 m²\n🛏 Pokoje: 3\n🏢 Piętro: 4\n💶 Czynsz adm.: 1000 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','SELL','FLAT','NEEDS_RENOVATION',899600,NULL,1000,NULL,86,NULL,3,4,NULL,2003,1,0,1,0,0,0,'Reszta kraju','Legionowo','Bolesława Chrobrego 6',NULL,52.40732923525242,20.92668384184958,1,NULL,'[\"/uploads/offers/144/8cd2d185-ac2b-48f9-9e2d-5c9128a5af13.webp\",\"/uploads/offers/144/cd9d7150-22e2-425c-bd3e-d2419a379996.webp\",\"/uploads/offers/144/a3b3ef5c-167e-4d35-a13a-8fb37d2db852.webp\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-05-04 19:45:12.870','2026-05-10 10:43:33.920',3,NULL,'2026-05-10 10:43:33.920',NULL,NULL),
(145,'Usnę skdbs znam','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na wynajem, zlokalizowany w sercu: Poznań. Nieruchomość jest z potencjałem do remontu, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 45 m²\n🛏 Pokoje: 2\n🏢 Piętro: Parter\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.','RENT','FLAT','NEEDS_RENOVATION',5000,NULL,NULL,5000,45,NULL,2,0,NULL,2018,1,0,0,1,0,0,'Poznań','Jeżyce','Jana Henryka Dąbrowskiego 160B',NULL,52.41782107342476,16.87981366717749,1,NULL,'[\"/uploads/offers/145/993b14ee-ee4a-4b00-b1a1-737a76214e34.webp\",\"/uploads/offers/145/cf4e6ee1-0334-4e68-b7b8-f65c931da61b.webp\",\"/uploads/offers/145/c6773b69-358a-4807-b5ea-bee4ad5c0873.webp\",\"/uploads/offers/145/84b2d958-3886-4694-a4b0-bf410ce54dd6.webp\",\"/uploads/offers/145/bffd13bf-c149-4612-8bf1-32879508b43f.webp\"]',NULL,NULL,'ARCHIVED',NULL,NULL,'2026-05-04 23:20:57.978','2026-05-10 10:43:33.629',3,NULL,'2026-05-10 10:43:33.629',NULL,NULL),
(152,'Świetna nieruchomość w Kalwarii','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Reszta kraju. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 66 m²\n🛏 Pokoje: 2\n🏢 Piętro: 1\n💶 Czynsz adm.: 1100 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiI2NiIsImxhbmRSZWdpc3RyeU51bWJlciI6IiIsInN0YXR1cyI6IlVOVkVSSUZJRUQifQ-->','SELL','FLAT','READY',849000,NULL,1100,NULL,66,NULL,2,1,NULL,2016,1,1,0,1,0,1,'Reszta kraju','Góra Kalwaria','Kalwaryjska 8B','66',51.98260115306132,21.21440000000005,0,NULL,'[\"/uploads/offers/152/f8dc2159-3328-4b78-a929-e76cd4d64fb9.webp\",\"/uploads/offers/152/a4014507-b924-4928-a364-5fc8cd3c1532.webp\",\"/uploads/offers/152/c54df167-5e26-40db-b4b5-c762eaa3515a.webp\",\"/uploads/offers/152/bb33a81c-abf9-4b4f-aa3f-1a5cf65233ac.webp\"]',NULL,'/uploads/offers/152/8b69d7e1-2171-484f-8fd8-5930cb354eb6.webp','ACTIVE',NULL,NULL,'2026-05-12 03:27:05.698','2026-05-12 04:49:43.029',3,'Miejskie',NULL,NULL,NULL),
(153,'Mieszkanie w Berlinie tanio','Rzadka okazja na rynku. Nieruchomość, która natychmiast przykuwa uwagę.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Reszta kraju. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 33 m²\n🛏 Pokoje: 3\n🏢 Piętro: 1\n💶 Czynsz adm.: 666 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',800000,NULL,666,NULL,33,NULL,3,1,NULL,2018,1,1,1,1,0,1,'Reszta kraju','Berlin','Landshuter Straße 3',NULL,52.49362077070314,13.33827786274461,1,NULL,'[\"/uploads/offers/153/1dc75ff1-2ef8-41a1-8243-abba34a28d62.webp\",\"/uploads/offers/153/e00bcd01-9b10-45e4-9289-035b161ee77c.webp\",\"/uploads/offers/153/127a81e3-0070-4804-917e-ee80dc8bcb90.webp\",\"/uploads/offers/153/286e1b67-a6b2-412d-b125-217dad85774f.webp\"]',NULL,'/uploads/offers/153/b4aad7a9-cc4c-476d-a621-ddc8cf58b10f.webp','ACTIVE',NULL,NULL,'2026-05-12 04:57:08.979','2026-05-12 04:58:09.816',38,'Miejskie',NULL,NULL,NULL),
(154,'Przepiękna nieruchomość położona przy praskim Koneserzy blisko dworca Wileńskiego.','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nZaledwie 3 minuty spacerem do głównych węzłów komunikacyjnych.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 56 m²\n🛏 Pokoje: 1\n🏢 Piętro: Parter\n💶 Czynsz adm.: 600 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',890000,NULL,600,NULL,56,NULL,2,2,NULL,2009,1,0,1,0,1,1,'Warszawa','Praga-Północ','Radzymińska 34',NULL,52.25817312443763,21.05191161317299,1,NULL,'[\"/uploads/offers/154/c449ead5-d8aa-4ef0-b0fb-c885f2a0eff5.webp\",\"/uploads/offers/154/ddf241a2-2cd9-40db-a345-dbbc817bb291.webp\",\"/uploads/offers/154/059ca715-0f64-4563-b11f-5414e99d48f1.webp\",\"/uploads/offers/154/ddf415ec-4c18-4e7f-853f-023aa65eaa81.webp\"]',NULL,NULL,'ACTIVE',NULL,NULL,'2026-05-12 05:54:26.883','2026-05-12 12:50:26.483',38,'Elektryczne',NULL,NULL,NULL),
(155,'Pięknie mieszkanie ','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 50 m²\n🛏 Pokoje: 2\n🏢 Piętro: 1\n💶 Czynsz adm.: 1200 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',600000,NULL,1200,NULL,50,NULL,2,1,NULL,2010,1,1,1,0,0,1,'Warszawa','Praga-Północ','Radzymińska 34',NULL,52.25802821883124,21.05185840364662,1,NULL,'[\"/uploads/offers/155/3103f3b3-c474-431f-9101-4a7a0704b598.webp\",\"/uploads/offers/155/6472b928-cb42-4c85-a1ea-f8e0e58904e7.webp\",\"/uploads/offers/155/fb16b973-c4ec-4df8-a246-b9936e771afe.webp\"]',NULL,'/uploads/offers/155/b1033e12-6e8f-4b29-b5e7-61e011742e5f.webp','ARCHIVED',NULL,NULL,'2026-05-12 06:28:02.140','2026-05-12 06:29:14.509',23,'Miejskie','2026-05-12 06:29:14.509',NULL,NULL),
(156,'Pięknie mieszkanie','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n\n✧ KLUCZOWE PARAMETRY ✧\n📐 Powierzchnia: 50 m²\n🛏 Pokoje: 2\n🏢 Piętro: 1\n💶 Czynsz adm.: 1200 PLN\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',600000,NULL,1200,NULL,50,NULL,2,1,NULL,2010,1,1,1,0,0,1,'Warszawa','Praga-Północ','Radzymińska 34',NULL,52.25802821883124,21.05185840364662,0,NULL,'[\"/uploads/offers/156/3e149f84-b807-40c0-acdb-c13cc82aa639.webp\",\"/uploads/offers/156/15dff131-a4e2-4394-93ff-17c8c2db1f7a.webp\",\"/uploads/offers/156/f1f26a67-10b6-4012-b944-8653c1e3680c.webp\"]',NULL,'/uploads/offers/156/1d95168b-2d55-4e63-b5f4-b3ec85b738b7.webp','ACTIVE',NULL,NULL,'2026-05-12 06:28:03.076','2026-05-12 06:32:52.700',23,'Miejskie',NULL,NULL,NULL),
(157,'Koziennice tower','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Kozienice. Nieruchomość jest w stanie deweloperskim, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nW promieniu 500 metrów znajdziesz renomowane szkoły i nowoczesny kompleks.\n🏫 Rodzinna infrastruktura (szkoły/przedszkola) jest osiągalna w krótkim czasie.\n🌿 W otoczeniu znajdziesz tereny rekreacyjne idealne na spacer, bieganie lub rower po pracy.\n🚇 Komunikacja miejska w wygodnym zasięgu (autobus/tramwaj) — codzienne dojazdy są szybkie i przewidywalne.\n\n✧ ANALIZA RYNKU ✧\nCENA RYNKOWA\nTo stabilna, rynkowa propozycja — bez sztucznego zawyżenia, z zachowaniem jakości oferty.\n📌 Cena ofertowa / średnia lokalna: 12 221 vs 12 000 PLN/m² (+2%)\n\n✧ UDOGODNIENIA ✧\n✓ Balkon / taras\n✓ Garaż / parking\n✓ Piwnica / komórka lokatorska\n✓ Winda\n✓ Ogródek\n✓ Umeblowane wnętrze\n\n✧ KLUCZOWE PARAMETRY ✧\n🔁 Typ transakcji: Sprzedaż\n🏷 Typ nieruchomości: Mieszkanie\n📐 Powierzchnia: 66 m²\n🛏 Pokoje: 2\n🏢 Piętro: Parter\n🗓 Rok budowy: 2020\n💰 Cena: 806 600 PLN\n📊 Cena za m²: 12 221 PLN\n💶 Czynsz adm.: 788 PLN\n🔥 Ogrzewanie: Elektryczne\n📍 Lokalizacja: Kozienice\n🧭 Adres: al 1 Maja 10\n🛰 Tryb lokalizacji: Dokładna (pin precyzyjny)\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',806600,NULL,788,NULL,66,NULL,2,0,NULL,2020,1,1,1,1,1,1,'Reszta kraju','Kozienice','al 1 Maja 10',NULL,51.58550093631219,21.54881354399199,1,NULL,'[\"/uploads/offers/157/011dbb87-f28f-494e-844b-028d1922ccda.webp\",\"/uploads/offers/157/0d34f962-d545-4154-9744-5c7ebbb83c50.webp\",\"/uploads/offers/157/0c0dc382-41d1-4955-8e1c-f3e1644c9613.webp\"]',NULL,'/uploads/offers/157/eb434e54-ffcd-472e-a426-eadae10f4882.webp','ARCHIVED',NULL,NULL,'2026-05-12 09:44:31.708','2026-05-12 13:28:06.276',39,'Elektryczne','2026-05-12 13:27:59.257','2026-05-12 13:27:59.257','DEAL_FINALIZED'),
(158,'Luksusowy dom na Pradze północ','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy dom na sprzedaż, zlokalizowany w sercu: Warszawa, Praga-Północ. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nDla aktywnych: ścieżki rowerowe, kluby fitness i bliskość rzeki.\nⓂ️ W zależności od dzielnicy stacje metra pozostają w praktycznym zasięgu komunikacji miejskiej.\n🏫 Rodzinna infrastruktura (szkoły/przedszkola) jest osiągalna w krótkim czasie.\n☕ Lokalizacja wspiera wygodny styl życia — kawiarnie, restauracje i codzienna infrastruktura są pod ręką.\n\n✧ ANALIZA RYNKU ✧\nOKAZJA\nW tym segmencie lokalnym to jedna z ciekawszych ofert cenowych dostępnych obecnie na rynku.\n📌 Cena ofertowa / średnia lokalna: 7 831 vs 16 500 PLN/m² (-53%)\n\n✧ UDOGODNIENIA ✧\n✓ Balkon / taras\n✓ Piwnica / komórka lokatorska\n✓ Winda\n✓ Umeblowane wnętrze\n\n✧ KLUCZOWE PARAMETRY ✧\n🔁 Typ transakcji: Sprzedaż\n🏷 Typ nieruchomości: Dom\n📐 Powierzchnia: 166 m²\n🛏 Pokoje: 1\n🏢 Piętro: Parter\n🗓 Rok budowy: 2026\n💰 Cena: 1 300 000 PLN\n📊 Cena za m²: 7 831 PLN\n💶 Czynsz adm.: 1 100 PLN\n🧱 Stan: Gotowe do wprowadzenia\n🔥 Ogrzewanie: Gazowe\n📍 Lokalizacja: Warszawa, Praga-Północ\n🧭 Adres: Radzymińska 34\n🔢 Numer lokalu: 16\n🛰 Tryb lokalizacji: Dokładna (pin precyzyjny)\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIxNiIsImxhbmRSZWdpc3RyeU51bWJlciI6IldBMU0vMDk4NzU2NjcvNiIsInN0YXR1cyI6IlBFTkRJTkdfUkVWSUVXIn0-->','SELL','HOUSE','READY',1300000,NULL,1100,NULL,166,NULL,1,0,NULL,2026,1,1,1,0,0,1,'Warszawa','Praga-Północ','Radzymińska 34','16',52.25802080639352,21.051850345715,1,NULL,'[\"/uploads/offers/158/3b4c4d87-01d1-4073-9bd2-dd49078d4b67.webp\",\"/uploads/offers/158/356cb208-76b8-483d-9099-8fec870c4ec8.webp\"]',NULL,'/uploads/offers/158/cbdcf4ea-bb94-4373-85d5-857f387272c6.webp','PENDING',NULL,NULL,'2026-05-12 14:55:03.148','2026-05-12 14:55:37.469',38,'Gazowe',NULL,NULL,NULL),
(163,'Agencyjnej oferta','Oto miejsce stworzone z myślą o osobach ceniących miejski styl życia.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa, Targówek. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n🚗 Dogodny wyjazd na główne trasy ułatwia poruszanie się po mieście i poza nim.\n🌿 W otoczeniu znajdziesz tereny rekreacyjne idealne na spacer, bieganie lub rower po pracy.\n🛍 W pobliżu dostępne są punkty usługowe: sklepy, piekarnie, apteki i strefa gastronomiczna.\n\n✧ ANALIZA RYNKU ✧\nOKAZJA\nW tym segmencie lokalnym to jedna z ciekawszych ofert cenowych dostępnych obecnie na rynku.\n📌 Cena ofertowa / średnia lokalna: 14 527 vs 16 500 PLN/m² (-12%)\n\n✧ UDOGODNIENIA ✧\n✓ Balkon / taras\n✓ Piwnica / komórka lokatorska\n✓ Ogródek\n✓ Umeblowane wnętrze\n\n✧ KLUCZOWE PARAMETRY ✧\n🔁 Typ transakcji: Sprzedaż\n🏷 Typ nieruchomości: Mieszkanie\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 2\n🏢 Piętro: 3\n🗓 Rok budowy: 2023\n💰 Cena: 799 000 PLN\n📊 Cena za m²: 14 527 PLN\n💶 Czynsz adm.: 680 PLN\n🧱 Stan: Gotowe do wprowadzenia\n🔥 Ogrzewanie: Miejskie\n📍 Lokalizacja: Warszawa, Targówek\n🧭 Adres: Smoleńska 60\n🛰 Tryb lokalizacji: Dokładna (pin precyzyjny)\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',799000,NULL,680,NULL,55,NULL,2,3,NULL,2023,1,0,1,0,1,1,'Warszawa','Targówek','Smoleńska 60',NULL,52.26779632959838,21.04851681013776,1,NULL,'[\"/uploads/offers/163/249c2b3b-abed-42ba-a75f-85e07073cc8b.webp\",\"/uploads/offers/163/a1dabbbf-ec0f-4a7d-91a5-6549abba8145.webp\"]',NULL,'/uploads/offers/163/a1bec027-4344-4572-8b25-c7ed24167136.webp','ARCHIVED',NULL,NULL,'2026-05-12 16:29:59.985','2026-05-12 16:49:46.111',45,'Miejskie',NULL,NULL,NULL),
(164,'Hcyxcuvh uvuchcivy ','Harmonia, spokój i doskonały design. Ta propozycja zadowoli najbardziej wymagających.\n\nPrezentujemy wyjątkowy apartament na sprzedaż, zlokalizowany w sercu: Warszawa, Targówek. Nieruchomość jest gotowy do wprowadzenia, co czyni ją niezwykle atrakcyjną ofertą.\n\n✧ ANALIZA OKOLICY ✧\nOtoczenie to kwintesencja wielkomiejskiego życia: kawiarnie i restauracje.\n📍 Adres został wskazany pinezką na mapie, co zwiększa precyzję dopasowania względem lokalnych potrzeb klienta.\n🏫 Rodzinna infrastruktura (szkoły/przedszkola) jest osiągalna w krótkim czasie.\n🚗 Dogodny wyjazd na główne trasy ułatwia poruszanie się po mieście i poza nim.\n\n✧ ANALIZA RYNKU ✧\nOKAZJA\nAnaliza porównawcza wskazuje na atrakcyjną wycenę względem podobnych ofert w najbliższej okolicy.\n📌 Cena ofertowa / średnia lokalna: 9 091 vs 16 500 PLN/m² (-45%)\n\n✧ UDOGODNIENIA ✧\n✓ Balkon / taras\n✓ Garaż / parking\n✓ Piwnica / komórka lokatorska\n✓ Winda\n✓ Ogródek\n✓ Umeblowane wnętrze\n\n✧ KLUCZOWE PARAMETRY ✧\n🔁 Typ transakcji: Sprzedaż\n🏷 Typ nieruchomości: Mieszkanie\n📐 Powierzchnia: 55 m²\n🛏 Pokoje: 2\n🏢 Piętro: Parter\n🗓 Rok budowy: 2011\n💰 Cena: 500 000 PLN\n📊 Cena za m²: 9 091 PLN\n💶 Czynsz adm.: 700 PLN\n🧱 Stan: Gotowe do wprowadzenia\n🔥 Ogrzewanie: Miejskie\n📍 Lokalizacja: Warszawa, Targówek\n🧭 Adres: Zamkowa 3\n🛰 Tryb lokalizacji: Dokładna (pin precyzyjny)\n\nZapraszamy do kontaktu w celu umówienia prywatnej prezentacji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',500000,NULL,700,NULL,55,NULL,2,0,NULL,2011,1,1,1,1,1,1,'Warszawa','Targówek','Zamkowa 3',NULL,52.2742966518091,21.07870317860417,1,0.5,'[\"/uploads/offers/164/6e56900e-1078-44dc-8739-524e817bd44c.webp\",\"/uploads/offers/164/c7e1ac6b-67b9-40f0-9492-97f72406d699.webp\"]',NULL,'/uploads/offers/164/bbce1914-e666-4d16-aa4d-c5de2b635c13.webp','ACTIVE',NULL,NULL,'2026-05-12 16:57:25.568','2026-05-12 17:41:05.295',45,'Miejskie',NULL,NULL,NULL),
(165,'Hcuvjvjkvbbbnnnnnnnbbbbbbbbbbbbbb Hcuvjvjkvbbbnnnnnnnbbbbbbbbbbbbbb Hcu','Przedstawiamy wyjątkową ofertę: FLAT w Praga-Północ o metrażu 44 m2. Komfortowy układ pomieszczeń, funkcjonalna przestrzeń oraz doskonała lokalizacja czynią tę nieruchomość idealną zarówno do zamieszkania, jak i inwestycji.\n\n<!--ESTATEOS_VERIFY:eyJhcGFydG1lbnROdW1iZXIiOiIiLCJsYW5kUmVnaXN0cnlOdW1iZXIiOiIiLCJzdGF0dXMiOiJVTlZFUklGSUVEIn0-->','SELL','FLAT','READY',850000,NULL,NULL,0,44,0,2,2,NULL,NULL,1,1,1,1,1,1,'Warszawa','Praga-Północ','Radzymińska 34',NULL,52.258079,21.051955,1,NULL,'[\"/uploads/offers/165/abd420e5-deee-49ad-9305-b82cfb8b57f9.webp\",\"/uploads/offers/165/d99232e6-dec6-4ba2-9a06-28a40665927f.webp\",\"/uploads/offers/165/76f8258a-1fef-4c2b-96a4-0b5d97b4d08e.webp\",\"/uploads/offers/165/0e4612a7-5625-41db-bbf9-f0822d8362eb.webp\"]',NULL,'/uploads/offers/165/a22bca43-6089-4c64-ae23-4282225d08d9.webp','PENDING',NULL,NULL,'2026-05-12 23:38:36.651','2026-05-12 23:38:49.467',38,'Gazowe',NULL,NULL,NULL);
/*!40000 ALTER TABLE `Offer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `OfferViewLog`
--

DROP TABLE IF EXISTS `OfferViewLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `OfferViewLog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `offerId` int(11) NOT NULL,
  `visitorKey` varchar(128) NOT NULL,
  `source` varchar(16) NOT NULL DEFAULT 'web',
  `ip` varchar(64) DEFAULT NULL,
  `userAgent` varchar(255) DEFAULT NULL,
  `hits` int(11) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `lastSeenAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `OfferViewLog_offerId_visitorKey_key` (`offerId`,`visitorKey`),
  KEY `OfferViewLog_offerId_lastSeenAt_idx` (`offerId`,`lastSeenAt`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OfferViewLog`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `OfferViewLog` WRITE;
/*!40000 ALTER TABLE `OfferViewLog` DISABLE KEYS */;
INSERT INTO `OfferViewLog` VALUES
(1,128,'user:22','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-04-30 06:11:13.803','2026-04-30 06:11:13.803'),
(2,128,'user:27','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',2,'2026-04-30 06:13:09.696','2026-04-30 06:20:44.860'),
(3,113,'user:27','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',5,'2026-04-30 06:42:14.596','2026-04-30 06:44:02.671'),
(4,106,'user:27','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',4,'2026-04-30 06:43:09.618','2026-05-06 09:22:06.627'),
(5,111,'user:3','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-04-30 12:00:03.037','2026-04-30 12:00:03.037'),
(6,110,'user:3','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-05-01 23:35:49.997','2026-05-01 23:35:49.997'),
(7,113,'user:3','web','::ffff:127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-05-01 23:37:40.073','2026-05-01 23:37:40.073'),
(8,106,'user:22','web','31.61.236.212','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-05-06 01:20:40.404','2026-05-06 01:20:40.404'),
(9,121,'user:27','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',1,'2026-05-06 09:26:04.479','2026-05-06 09:26:04.479'),
(10,111,'user:27','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',1,'2026-05-06 09:26:17.584','2026-05-06 09:26:17.584'),
(11,1,'anon:3b9cbf72bb470261e7e4adcc61b0e86facc631ce5afbb1c74155c2744c54eaf3','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',2,'2026-05-06 09:28:50.612','2026-05-06 09:29:08.110'),
(12,138,'user:3','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',1,'2026-05-06 09:42:50.272','2026-05-06 09:42:50.272'),
(13,114,'user:23','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',2,'2026-05-06 09:47:49.012','2026-05-06 09:50:06.848'),
(14,119,'user:23','web','192.168.50.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1',1,'2026-05-06 09:50:42.175','2026-05-06 09:50:42.175'),
(15,112,'user:22','web','192.168.50.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',4,'2026-05-06 12:21:15.530','2026-05-06 14:00:02.479'),
(16,123,'user:22','web','88.156.182.147','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',4,'2026-05-06 15:00:53.919','2026-05-06 21:16:08.067'),
(17,151,'user:22','web','88.156.182.147','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-05-11 13:15:57.079','2026-05-11 13:15:57.079'),
(18,114,'user:28','web','88.156.182.147','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15',1,'2026-05-11 13:28:49.061','2026-05-11 13:28:49.061'),
(22,157,'user:38','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 15:19:30.348','2026-05-12 15:19:30.348'),
(23,114,'user:38','mobile','192.168.50.1','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',3,'2026-05-12 15:33:42.886','2026-05-13 10:27:11.770'),
(24,156,'user:38','mobile','192.168.50.1','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',2,'2026-05-12 15:34:00.641','2026-05-13 10:24:20.140'),
(25,116,'user:38','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 15:34:08.508','2026-05-12 15:34:08.508'),
(26,154,'user:39','mobile','192.168.50.1','EstateOS/1 CFNetwork/3826.600.41.2.1 Darwin/24.6.0',1,'2026-05-12 16:43:04.332','2026-05-12 16:43:04.332'),
(27,156,'user:45','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 18:26:14.088','2026-05-12 18:26:14.088'),
(28,154,'user:45','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 18:26:17.814','2026-05-12 18:26:17.814'),
(29,164,'user:3','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 19:36:18.981','2026-05-12 19:36:18.981'),
(30,158,'user:3','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 19:36:42.775','2026-05-12 19:36:42.775'),
(31,156,'user:3','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 19:52:45.559','2026-05-12 19:52:45.559'),
(32,164,'user:38','mobile','192.168.50.1','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',2,'2026-05-12 20:09:44.371','2026-05-13 10:24:40.650'),
(33,164,'anon:1c2b237eed3a3f9bc8021ec01392a374be9dda813eed8c523e309a4aa377d925','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 21:10:59.850','2026-05-12 21:10:59.850'),
(34,154,'anon:1c2b237eed3a3f9bc8021ec01392a374be9dda813eed8c523e309a4aa377d925','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 21:11:04.740','2026-05-12 21:11:04.740'),
(35,164,'user:23','mobile','5.173.152.35','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 21:26:54.840','2026-05-12 21:26:54.840'),
(36,164,'anon:2df7fae14a9120996a66c34e5babb7d39098a78ecbc6600c20b9dac2af51d5cf','mobile','192.168.50.1','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 21:39:46.508','2026-05-12 21:39:46.508'),
(37,154,'user:3','mobile','192.168.50.1','EstateOS/19 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-12 22:07:36.533','2026-05-12 22:07:36.533'),
(38,114,'user:46','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-13 13:55:01.272','2026-05-13 13:55:01.272'),
(39,164,'user:46','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-13 14:05:25.607','2026-05-13 14:05:25.607'),
(40,154,'user:46','mobile','192.168.50.1','EstateOS/1 CFNetwork/3860.500.112 Darwin/25.4.0',1,'2026-05-13 14:07:43.321','2026-05-13 14:07:43.321');
/*!40000 ALTER TABLE `OfferViewLog` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `PageVisitLog`
--

DROP TABLE IF EXISTS `PageVisitLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PageVisitLog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `visitorHash` varchar(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `country` varchar(8) NOT NULL DEFAULT 'PL',
  `path` varchar(191) NOT NULL DEFAULT '/',
  `userAgent` varchar(255) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `PageVisitLog_path_createdAt_idx` (`path`,`createdAt`),
  KEY `PageVisitLog_hash_createdAt_idx` (`visitorHash`,`createdAt`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PageVisitLog`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `PageVisitLog` WRITE;
/*!40000 ALTER TABLE `PageVisitLog` DISABLE KEYS */;
INSERT INTO `PageVisitLog` VALUES
(1,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 04:48:07.143'),
(2,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:10:53.973'),
(3,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/128','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:11:13.444'),
(4,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:11:21.270'),
(5,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:11:21.483'),
(6,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:11:25.090'),
(7,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:41:34.485'),
(8,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:42:02.471'),
(9,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/113','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:42:14.438'),
(10,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/106','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 06:43:09.485'),
(11,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 07:13:29.709'),
(12,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 07:13:43.242'),
(13,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 07:48:55.399'),
(14,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 07:55:44.038'),
(15,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 09:34:24.778'),
(16,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 09:34:29.625'),
(17,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 09:34:30.815'),
(18,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 09:34:44.362'),
(19,'d70c389ad1a98ddd155ed7e86b998a91172a0bb84f3a7951013f9c2224cba8ca','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7727.116 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','2026-04-30 09:44:31.687'),
(20,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/cennik','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 10:41:57.673'),
(21,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-04-30 10:42:20.241'),
(22,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 11:14:12.001'),
(23,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 11:14:53.707'),
(24,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 11:59:23.484'),
(25,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/111','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-04-30 12:00:02.573'),
(26,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 01:39:16.102'),
(27,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 01:39:51.675'),
(28,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 01:42:03.468'),
(29,'3ee048859d15114651e8d269125e81781f7937e8ad588469d4ac78b3d64bc36c','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7727.137 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','2026-05-01 03:15:17.212'),
(30,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 11:53:52.409'),
(31,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 13:13:47.853'),
(32,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 16:03:23.305'),
(33,'ef3572b712f9349d1455bcec3996e6b2d5fe1d9094d6fbc38095c85a1a61ad63','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','2026-05-01 20:42:09.731'),
(34,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 21:16:30.733'),
(35,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 21:17:02.792'),
(36,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-01 23:04:44.385'),
(37,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 23:35:22.514'),
(38,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/110','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 23:35:49.801'),
(39,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/oferta/113','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 23:37:39.895'),
(40,'48fc0abef0d8be8907d01b619940b73ee39586b457775eaff58044e123a4b6a1','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-01 23:42:47.583'),
(41,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-02 00:47:34.198'),
(42,'e48db5ae9fe2550273bd728434d4705d25099a7d19e92dc73f3d563e11f81f8c','::ffff:127.0.0.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-02 00:47:51.081'),
(43,'575ee3a3f7e4db6157972385a3de88e7dca8376e61bbacd1ce51668818d8d6e9','5.173.16.47','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-02 09:37:33.627'),
(44,'de76b13f7f2adfed351e20b9f36796037da955d17ce8aed1471e7197598c727e','5.173.220.6','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-02 09:38:42.958'),
(45,'575ee3a3f7e4db6157972385a3de88e7dca8376e61bbacd1ce51668818d8d6e9','5.173.16.47','PL','/o/%7Bid%7D','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-02 09:40:21.618'),
(46,'575ee3a3f7e4db6157972385a3de88e7dca8376e61bbacd1ce51668818d8d6e9','5.173.16.47','PL','/o/%7B128%7D','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-02 09:40:48.021'),
(47,'0bd61d45b389374ceae0e7e649b90e0d79ce143250cd696805ab049f004459c1','5.173.16.47','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/558.2.0.42.110;FBBV/952277649;FBDV/iPhone16,2;FBMD/iPhone;FBSN/iOS;FBSV/26.4.2;FBSS/3;FBCR/;FBID/phone;FBLC/pl_PL;FBOP/80]','2026-05-02 11:02:34.735'),
(48,'0bd61d45b389374ceae0e7e649b90e0d79ce143250cd696805ab049f004459c1','5.173.16.47','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/558.2.0.42.110;FBBV/952277649;FBDV/iPhone16,2;FBMD/iPhone;FBSN/iOS;FBSV/26.4.2;FBSS/3;FBCR/;FBID/phone;FBLC/pl_PL;FBOP/80]','2026-05-02 12:10:07.138'),
(49,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-02 12:30:15.413'),
(50,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-02 12:30:19.806'),
(51,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-02 22:03:23.156'),
(52,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-02 22:07:29.438'),
(53,'ed0b17d437c00fbd2ad7173796a6dea9b537b84868acac9e41fe26699822716d','44.223.35.38','PL','/','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','2026-05-03 15:08:09.513'),
(54,'fc47f6eea401bc1dde0280fbc930f1fea5270625c9cd5024a4e60a01feae5edc','66.249.73.99','PL','/','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7727.137 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','2026-05-04 11:05:49.780'),
(55,'f6ce803ad733ce7f3116ce4c45fcb131513625d8064c11b8db475ee5c1edf42a','79.184.251.75','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 00:42:12.323'),
(56,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 15:57:18.328'),
(57,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 16:36:24.633'),
(58,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:17:35.181'),
(59,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:17:45.348'),
(60,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:17:53.875'),
(61,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/szukaj','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:25:17.227'),
(62,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:25:31.713'),
(63,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 17:28:43.147'),
(64,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 18:25:54.535'),
(65,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:32:34.719'),
(66,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:33:54.840'),
(67,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_click?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:58:59.420'),
(68,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_route_resolved?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:58:59.891'),
(69,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_flow_opened?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:58:59.929'),
(70,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_click?cta=INVESTOR&mode=INVESTOR&route=%2Foferty','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:58:59.999'),
(71,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_flow_opened?cta=INVESTOR&mode=INVESTOR&route=%2Foferty','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:59:00.071'),
(72,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/event/home_cta_route_resolved?cta=INVESTOR&mode=INVESTOR&route=%2Foferty','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 18:59:00.243'),
(73,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/oferty','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 19:02:50.758'),
(74,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 19:02:57.013'),
(75,'d7a4b6b13f2a7d6c118afaf97067854a5d0fc1c5a941c82b6214fcf86f7cd498','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 19:03:12.959'),
(76,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 19:24:08.064'),
(77,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 19:37:36.025'),
(78,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 19:39:12.392'),
(79,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:52:24.721'),
(80,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:52:37.381'),
(81,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:23.444'),
(82,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:23.565'),
(83,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:23.567'),
(84,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:29.045'),
(85,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:29.139'),
(86,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:29.159'),
(87,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 22:57:29.368'),
(88,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 23:08:54.810'),
(89,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 23:08:54.811'),
(90,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=OWNER&mode=OWNER&route=%2Fmoje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 23:08:54.842'),
(91,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-05 23:08:54.961'),
(92,'75c5322345fc2af4a14be5b53e8234f5a8cec2947c2f5ce177fe06b1fd7c6cae','5.173.159.73','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 23:56:31.542'),
(93,'75c5322345fc2af4a14be5b53e8234f5a8cec2947c2f5ce177fe06b1fd7c6cae','5.173.159.73','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-05 23:56:48.451'),
(94,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 00:52:19.450'),
(95,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 00:52:34.123'),
(96,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 00:52:34.125'),
(97,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 00:52:34.146'),
(98,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:00:45.425'),
(99,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:00:45.466'),
(100,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:00:45.483'),
(101,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:00:45.690'),
(102,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:06:43.450'),
(103,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:08:54.543'),
(104,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/oferta/106','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 01:20:40.109'),
(105,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:02:57.910'),
(106,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:12:43.779'),
(107,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:12:43.783'),
(108,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:12:44.019'),
(109,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:12:44.554'),
(110,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 02:37:15.890'),
(111,'c0d0795acb46828508aaea166286712f31fc63231aede20a5c8b4b8d039c022f','188.245.62.219','PL','/','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/147.0.0.0 Safari/537.36','2026-05-06 06:49:27.645'),
(112,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:20:06.692'),
(113,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/106','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:20:25.908'),
(114,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:22:32.535'),
(115,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:22:32.535'),
(116,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:22:32.539'),
(117,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/121','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:26:04.330'),
(118,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/111','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:26:17.464'),
(119,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:28:12.807'),
(120,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/cennik','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:28:27.473'),
(121,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferty','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:28:47.113'),
(122,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:28:50.592'),
(123,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:29:46.238'),
(124,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:29:46.276'),
(125,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:29:46.301'),
(126,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:29:46.403'),
(127,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:37:30.976'),
(128,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/edytuj-oferte/145','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:38:02.845'),
(129,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/138','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:42:50.252'),
(130,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/114','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:47:48.876'),
(131,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:49:23.722'),
(132,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:50:17.658'),
(133,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/119','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:50:42.100'),
(134,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:54:14.349'),
(135,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:54:14.353'),
(136,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:54:14.353'),
(137,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/szukaj','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 09:55:15.536'),
(138,'9b0f8183fa2e19b9b6c1f841cfa5d6dc615b5dc0e9bbfcf12235dbf40abb4427','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1','2026-05-06 10:36:13.899'),
(139,'9b0f8183fa2e19b9b6c1f841cfa5d6dc615b5dc0e9bbfcf12235dbf40abb4427','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1','2026-05-06 10:36:15.099'),
(140,'9b0f8183fa2e19b9b6c1f841cfa5d6dc615b5dc0e9bbfcf12235dbf40abb4427','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1','2026-05-06 10:36:57.409'),
(141,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 11:09:31.029'),
(142,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 11:09:33.518'),
(143,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 11:54:55.740'),
(144,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/oferta/112','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 12:21:15.355'),
(145,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 12:31:36.820'),
(146,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:03:41.834'),
(147,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:03:48.893'),
(148,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:04:07.035'),
(149,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:04:13.284'),
(150,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:04:17.919'),
(151,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:17:05.296'),
(152,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:17:05.352'),
(153,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:17:05.447'),
(154,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:19:32.880'),
(155,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:19:32.996'),
(156,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:19:33.026'),
(157,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:19:33.179'),
(158,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 13:28:40.251'),
(159,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:57:46.294'),
(160,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 13:59:40.554'),
(161,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/oferta/112','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:00:02.129'),
(162,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:00:24.429'),
(163,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:00:24.507'),
(164,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:44:24.330'),
(165,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:44:25.680'),
(166,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:44:25.892'),
(167,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:58:36.900'),
(168,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:58:36.901'),
(169,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:58:36.935'),
(170,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 14:58:37.107'),
(171,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/oferta/123','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 15:00:53.755'),
(172,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 15:17:54.067'),
(173,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 15:26:28.197'),
(174,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 15:35:51.548'),
(175,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 15:54:42.950'),
(176,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 17:29:37.211'),
(177,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 17:30:10.210'),
(178,'dacf8d3da9df33de81ca76870824477f4992ed3aee82fe70dd6c25b8c68502de','5.173.159.26','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 17:37:03.109'),
(179,'dacf8d3da9df33de81ca76870824477f4992ed3aee82fe70dd6c25b8c68502de','5.173.159.26','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 17:37:04.364'),
(180,'dacf8d3da9df33de81ca76870824477f4992ed3aee82fe70dd6c25b8c68502de','5.173.159.26','PL','/oferta/119','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 17:37:38.458'),
(181,'dacf8d3da9df33de81ca76870824477f4992ed3aee82fe70dd6c25b8c68502de','5.173.159.26','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-06 17:38:26.009'),
(182,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 18:11:36.642'),
(183,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 20:48:29.220'),
(184,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/oferta/123','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 20:49:57.264'),
(185,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 21:15:54.549'),
(186,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 21:25:32.900'),
(187,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 21:26:47.267'),
(188,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 22:29:16.580'),
(189,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 22:29:29.720'),
(190,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-06 22:29:29.952'),
(191,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-07 00:05:31.320'),
(192,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-07 00:05:34.243'),
(193,'9b0f8183fa2e19b9b6c1f841cfa5d6dc615b5dc0e9bbfcf12235dbf40abb4427','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1','2026-05-07 06:50:36.500'),
(194,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-07 06:54:15.266'),
(195,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-07 06:54:18.366'),
(196,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-07 06:54:28.698'),
(197,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/cennik','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-07 22:23:07.937'),
(198,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/szukaj','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-07 22:23:48.594'),
(199,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-07 22:24:37.914'),
(200,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-07 22:25:08.243'),
(201,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-07 22:25:31.348'),
(202,'38452db7d376bf93344a8811df76f8916e812273cee13c11d0eb6a60f1cd0ab3','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/559.0.0.40.105;FBBV/955589806;FBDV/iPhone18,1;FBMD/iPhone;FBSN/iOS;FBSV/26.4.2;FBSS/3;FBCR/;FBID/phone;FBLC/pl_PL;FBOP/80]','2026-05-07 22:30:27.168'),
(203,'90bca6e7c2100d2177e238b2d9eafe97f458693b58604dc03622e8e7ba4d1146','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/560.0.0.29.108;FBBV/961605262;FBDV/iPhone16,2;FBMD/iPhone;FBSN/iOS;FBSV/26.4.2;FBSS/3;FBCR/;FBID/phone;FBLC/pl_PL;FBOP/80]','2026-05-07 23:30:46.720'),
(204,'2cff9fda96ea9efe0eb5b1da09212fec8f9072864b97ff686730b42affd16846','8.230.115.246','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36','2026-05-08 02:58:34.178'),
(205,'dd75f67ac639b16bde889637edd5431954c86a1f497b4050b0393c130cf75a9b','54.71.187.124','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-05-08 02:58:51.970'),
(206,'8b6fae6f17fa6a23a7c63c4045308a688109624218aa7821763a9580dd132e0f','103.4.249.1','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-05-08 02:59:52.971'),
(207,'015f0592ccfdb29d5a56a079870036cbdbd67c713f688ada9a9d10bf54a73819','185.152.39.14','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-05-08 03:00:41.415'),
(208,'2e473b0d36e337189994b28b8f24292c75801ccf0092de196bd5eb660c2b4c94','147.185.226.16','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2026-05-08 03:01:42.220'),
(209,'79b18967d0f26cc63a87248d99abedfa1572f8804ebbf0d142b439b5ccba5b1e','205.169.39.14','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','2026-05-08 04:01:36.597'),
(210,'55e356f819daab0dc0ae75b1e515a07b5163bcfb6fceac455243fee31feade27','205.169.39.58','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.132 Safari/537.36','2026-05-08 04:04:14.764'),
(211,'1ed2c43f327299e46cc3674dde51f1f1a74175a7d51a5e0c70f8e20f265b391f','44.245.203.34','PL','/','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0','2026-05-08 04:47:33.415'),
(212,'c2bd46b84263d5fa06e9b1f94b030ec76d28f58d78e71256fb0687cf2aa17889','119.12.201.43','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/144.0.7559.95 Mobile/15E148 Safari/604.1','2026-05-08 05:09:05.767'),
(213,'5fe523d9edb331881a6120a6fa610f0467b671f6e525adb95166481f5b9d814d','100.25.152.210','PL','/','Mozilla/5.0 (compatible; Konqueror/4.5; Windows) KHTML/4.5.4 (like Gecko)','2026-05-08 11:36:58.863'),
(214,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 19:48:45.031'),
(215,'28a732fc35d74f4676a4d3bbf80b8ec1dd161985f91cbf43e24500ebdeb16656','83.175.182.12','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 21:41:28.515'),
(216,'28a732fc35d74f4676a4d3bbf80b8ec1dd161985f91cbf43e24500ebdeb16656','83.175.182.12','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 21:42:25.031'),
(217,'28a732fc35d74f4676a4d3bbf80b8ec1dd161985f91cbf43e24500ebdeb16656','83.175.182.12','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 21:42:25.232'),
(218,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 22:24:47.285'),
(219,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 22:27:02.836'),
(220,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-08 22:27:03.130'),
(221,'ee114aa8ec7656eb235b211c93dd67af2183a2eb25defb9c25ab43dd80cc5a8d','5.173.27.32','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/560.0.0.29.108;FBBV/961605262;FBDV/iPhone15,2;FBMD/iPhone;FBSN/iOS;FBSV/26.3.1;FBSS/3;FBCR/;FBID/phone;FBLC/pl_PL;FBOP/80]','2026-05-08 22:46:46.254'),
(222,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 00:04:38.027'),
(223,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 00:04:40.458'),
(224,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 00:04:40.647'),
(225,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 00:04:54.407'),
(226,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 02:28:53.391'),
(227,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 02:38:52.838'),
(228,'8ae8dd59870cfb74fd54aa97accf052d532f9c894d871b824295b4ce09c37977','31.61.236.212','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-09 02:38:52.983'),
(229,'8d458fc5ca8dc8796048ed30f4e36f9e90113ff66ea1fbd8b322b515d37c02d9','66.249.73.98','PL','/','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7727.137 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','2026-05-10 09:31:19.083'),
(230,'13e09f5101f07cebb360b263fe2821e14e21a65af70c3d5fbad5afcec74a64a1','66.249.73.98','PL','/','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7727.116 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','2026-05-10 23:40:45.155'),
(231,'c00c5a36494ec57545dd8165b8125df047294182e77511ac73c939d22551d3d7','66.249.73.98','PL','/','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Googlebot/2.1; +http://www.google.com/bot.html) Chrome/147.0.7727.116 Safari/537.36','2026-05-10 23:40:47.194'),
(232,'f8fbc7d7415b4c39a56b4ae9a45eb042330f636d4ab261581f2bf5769bd2a037','51.158.248.230','PL','/','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.3','2026-05-11 02:41:24.818'),
(233,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:05:43.533'),
(234,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:09:46.376'),
(235,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:15:07.441'),
(236,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/oferta/151','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:15:56.835'),
(237,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:20:51.350'),
(238,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:20:51.351'),
(239,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:20:51.605'),
(240,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:20:51.812'),
(241,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:21:18.524'),
(242,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:21:18.529'),
(243,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:21:18.529'),
(244,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:24:49.628'),
(245,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/oferta/114','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:28:48.940'),
(246,'49a07968d93d26aa9c7704156d16b6b1ba8b93f03f12abcbefa49ab4b20962a4','88.156.182.147','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 13:37:29.967'),
(247,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-11 21:53:10.161'),
(248,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 04:01:18.486'),
(249,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_click?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 04:04:09.827'),
(250,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_route_resolved?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 04:04:09.844'),
(251,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_flow_opened?cta=SELL&mode=SELLER&route=%2Fdodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 04:04:09.856'),
(252,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 04:04:09.951'),
(253,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/cennik','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-12 07:57:36.041'),
(254,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-12 10:16:06.011'),
(255,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-12 10:16:25.151'),
(256,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 10:23:25.298'),
(257,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 14:37:47.974'),
(258,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 14:37:52.128'),
(259,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 14:37:52.224'),
(260,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 14:38:16.634'),
(261,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 16:05:05.846'),
(262,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 19:42:26.974'),
(263,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 19:42:41.797'),
(264,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/oferta/164','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 19:43:17.453'),
(265,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:10:40.750'),
(266,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_click?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:10:45.213'),
(267,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_route_resolved?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:10:45.213'),
(268,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/event/home_cta_flow_opened?cta=BUY&mode=BUYER&route=%2F%23map','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:10:45.218'),
(269,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:11:19.013'),
(270,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/login','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:12:52.969'),
(271,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-12 20:13:08.123'),
(272,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-12 21:56:53.725'),
(273,'04ff903e539c0feed043dd086479a482c6a5a2646657f2ecbdfbc5d33a03add4','5.173.218.108','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-12 22:36:15.486'),
(274,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/login','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:34:29.997'),
(275,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:34:42.364'),
(276,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/dodaj-oferte','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:35:30.288'),
(277,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/profil/3','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:40:02.317'),
(278,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/cennik','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:43:44.417'),
(279,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/moje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:46:39.576'),
(280,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:46:44.535'),
(281,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/oferta/114','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:47:49.959'),
(282,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/profil/23','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 01:51:54.806'),
(283,'0be6ce38c3753c6fae39d11d597455490888edf193d715ed292c3ff120969c72','5.173.152.35','PL','/moje-konto/crm','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 10:13:10.983'),
(284,'0be6ce38c3753c6fae39d11d597455490888edf193d715ed292c3ff120969c72','5.173.152.35','PL','/moje-konto','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 10:13:29.489'),
(285,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/regulamin','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-13 12:55:45.932'),
(286,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/polityka-prywatnosci','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 13:46:32.286'),
(287,'c60dd561a2590e524e791db4ced77c42cab47b3ff490938d8de5250d99c379f5','192.168.50.1','PL','/moje-konto/crm','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15','2026-05-13 17:14:27.576'),
(288,'bd161ee7f9c32281795f525c76e61ba21c83c01833655d80248fadb28706fa32','192.168.50.1','PL','/polityka-prywatnosci','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','2026-05-13 17:26:56.670');
/*!40000 ALTER TABLE `PageVisitLog` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `RadarPreference`
--

DROP TABLE IF EXISTS `RadarPreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `RadarPreference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `transactionType` enum('SELL','RENT') DEFAULT NULL,
  `propertyType` enum('FLAT','HOUSE','PLOT','COMMERCIAL') DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `districts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`districts`)),
  `maxPrice` double DEFAULT NULL,
  `minArea` double DEFAULT NULL,
  `minYear` int(11) DEFAULT NULL,
  `requireBalcony` tinyint(1) NOT NULL DEFAULT 0,
  `requireGarden` tinyint(1) NOT NULL DEFAULT 0,
  `requireElevator` tinyint(1) NOT NULL DEFAULT 0,
  `requireParking` tinyint(1) NOT NULL DEFAULT 0,
  `requireFurnished` tinyint(1) NOT NULL DEFAULT 0,
  `pushNotifications` tinyint(1) NOT NULL DEFAULT 1,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `radius` double DEFAULT NULL,
  `minMatchThreshold` int(11) NOT NULL DEFAULT 70,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RadarPreference_userId_key` (`userId`),
  CONSTRAINT `RadarPreference_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RadarPreference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `RadarPreference` WRITE;
/*!40000 ALTER TABLE `RadarPreference` DISABLE KEYS */;
INSERT INTO `RadarPreference` VALUES
(6,3,'SELL',NULL,'Marki','[]',1470000,NULL,1900,0,0,0,0,0,1,52.32532022851031,21.10434605334288,6.3,100),
(7,23,'SELL',NULL,'Góra Kalwaria','[]',5000000,NULL,1900,0,0,0,0,0,1,51.99489180003367,21.20842516663085,4.5,100),
(8,24,'SELL',NULL,'Warszawa','[]',5000000,NULL,1900,0,0,0,0,0,1,NULL,NULL,NULL,100),
(12,38,'RENT','COMMERCIAL','Podolszyn Nowy','[]',17700,34,1957,1,1,1,0,1,1,52.11732246621162,20.94873791702947,2.3,100),
(13,45,'SELL','FLAT','Warszawa','[\"Bemowo\",\"Białołęka\",\"Bielany\",\"Mokotów\",\"Ochota\",\"Praga-Południe\",\"Praga-Północ\",\"Rembertów\",\"Śródmieście\",\"Targówek\",\"Ursus\",\"Ursynów\",\"Wawer\",\"Wesoła\",\"Wilanów\",\"Włochy\",\"Wola\",\"Żoliborz\"]',1490000,41,1966,0,0,0,0,0,1,51.98375517813283,20.83365628364063,1.5,100);
/*!40000 ALTER TABLE `RadarPreference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Review`
--

DROP TABLE IF EXISTS `Review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealId` int(11) NOT NULL,
  `reviewerId` int(11) NOT NULL,
  `revieweeId` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `isAutoGenerated` tinyint(1) NOT NULL DEFAULT 0,
  `source` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Review_dealId_reviewerId_key` (`dealId`,`reviewerId`),
  UNIQUE KEY `Review_dealId_reviewerId_revieweeId_key` (`dealId`,`reviewerId`,`revieweeId`),
  KEY `Review_revieweeId_fkey` (`revieweeId`),
  KEY `Review_reviewerId_fkey` (`reviewerId`),
  CONSTRAINT `Review_dealId_fkey` FOREIGN KEY (`dealId`) REFERENCES `Deal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Review_revieweeId_fkey` FOREIGN KEY (`revieweeId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Review_reviewerId_fkey` FOREIGN KEY (`reviewerId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Review`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Review` WRITE;
/*!40000 ALTER TABLE `Review` DISABLE KEYS */;
INSERT INTO `Review` VALUES
(13,5,38,3,5,'Super','2026-05-12 11:20:06.403',0,NULL),
(14,5,3,38,5,'Fantastic','2026-05-12 11:20:43.771',0,NULL);
/*!40000 ALTER TABLE `Review` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `Session`
--

DROP TABLE IF EXISTS `Session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Session` (
  `id` varchar(191) NOT NULL,
  `sessionToken` varchar(191) NOT NULL,
  `userId` int(11) NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Session_sessionToken_key` (`sessionToken`),
  KEY `Session_userId_fkey` (`userId`),
  CONSTRAINT `Session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Session`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `Session` WRITE;
/*!40000 ALTER TABLE `Session` DISABLE KEYS */;
/*!40000 ALTER TABLE `Session` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `companyName` varchar(191) DEFAULT NULL,
  `nip` varchar(191) DEFAULT NULL,
  `role` enum('USER','AGENT','ADMIN') NOT NULL DEFAULT 'USER',
  `planType` enum('NONE','PRO','AGENCY','INVESTOR') NOT NULL DEFAULT 'NONE',
  `extraListings` int(11) NOT NULL DEFAULT 0,
  `proExpiresAt` datetime(3) DEFAULT NULL,
  `isVerified` tinyint(1) NOT NULL DEFAULT 0,
  `otpCode` varchar(191) DEFAULT NULL,
  `otpExpiry` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `isPro` tinyint(1) NOT NULL DEFAULT 0,
  `searchAmenities` varchar(191) DEFAULT NULL,
  `searchAreaFrom` int(11) DEFAULT NULL,
  `searchDistricts` varchar(191) DEFAULT NULL,
  `searchMaxPrice` int(11) DEFAULT NULL,
  `searchRooms` int(11) DEFAULT NULL,
  `searchTransactionType` varchar(191) DEFAULT NULL,
  `searchType` varchar(191) DEFAULT NULL,
  `buyerType` varchar(191) DEFAULT NULL,
  `searchAreaTo` int(11) DEFAULT NULL,
  `searchPlotArea` int(11) DEFAULT NULL,
  `emailVerifiedAt` datetime(3) DEFAULT NULL,
  `pendingEmail` varchar(191) DEFAULT NULL,
  `pendingEmailCode` varchar(16) DEFAULT NULL,
  `pendingEmailExpiresAt` datetime(3) DEFAULT NULL,
  `emailVerifyCode` varchar(16) DEFAULT NULL,
  `emailVerifyExpiresAt` datetime(3) DEFAULT NULL,
  `phoneVerifiedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_phone_key` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES
(3,'irommar@me.com',NULL,'$2b$10$2YSYTRQChcTpjuNccrFGJ.bYgs3.5WjbLUAe8vbh9fAeaKcmQXv4.','Zarząd EstateOS','/uploads/avatars/3-1776153628051.jpg','Nieruchomości WAW Sp. z o.o.',NULL,'ADMIN','AGENCY',0,'2026-05-26 18:13:42.666',1,NULL,NULL,'2026-04-11 03:44:00.106','2026-05-08 13:38:33.858',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-08 13:38:33.858',NULL,NULL,NULL,NULL,NULL,'2026-05-12 19:34:12.042'),
(23,'anna74@buziaczek.pl','+48 505933187','$2b$10$ijsV8V8UrIawroxYE61uV.Ax2sKlAFXDqIFFFOL761Re9yWys7jm2','Anna Pyszak','/uploads/avatars/23-1777753139126.jpg',NULL,NULL,'USER','NONE',1,NULL,1,NULL,NULL,'2026-04-25 19:05:13.824','2026-05-12 19:24:48.352',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 20:18:59.131',NULL,NULL,NULL,NULL,NULL,'2026-05-12 06:28:45.672'),
(24,'lukasz_sto@vp.pl','+48 796888346','$2b$10$ns4BYIZGSn1vGsy61h6h9uPQ1Uc3oRrYpICmxlHQ6JlOTTeYmwvTG','Lukas Sto',NULL,NULL,NULL,'USER','NONE',0,NULL,1,NULL,NULL,'2026-04-27 23:09:09.812','2026-04-27 23:09:48.296',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-27 23:09:48.296',NULL,NULL,NULL,NULL,NULL,NULL),
(36,'jan@kowalski.pl','+48 987 654 321','$2b$10$FxwOZVP41t1q.HYBeofJAOOlyDdkc1XaluBE9S8SsFHfDn98ko0Qq','Jan Kowalski',NULL,NULL,NULL,'USER','NONE',0,NULL,0,NULL,NULL,'2026-05-11 19:12:53.573','2026-05-11 19:12:54.169',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'497139','2026-05-11 19:27:54.167',NULL),
(38,'irommar@icloud.com','+48 883 040 044','$2b$10$XmncyfFP5puFH7dZuaLqFOby.Hng3pFUfCR1ECMVv9OujFMxX0VdS','Jan Nowak','/uploads/avatars/38-1778576983488.jpg',NULL,NULL,'USER','PRO',0,'2026-06-11 23:44:58.461',1,NULL,NULL,'2026-05-11 20:34:49.396','2026-05-12 23:44:58.462',1,NULL,22,'Praga-Południe,Praga-Północ,Mokotów',1500000,NULL,'all',NULL,NULL,NULL,NULL,'2026-05-11 20:36:38.997',NULL,NULL,NULL,NULL,NULL,'2026-05-11 20:35:34.696'),
(39,'mromanienko@metrohouse.pl','+48 733 344 955','$2b$10$in2qhezBic0AQCipQMIK2eIgkg6loZ3Kuyi45i/WcwMTEs567naBi','Marian Romanienko','/uploads/avatars/39-1778577030867.jpg',NULL,NULL,'USER','NONE',0,NULL,1,NULL,NULL,'2026-05-12 08:42:19.221','2026-05-12 09:10:30.872',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-12 09:06:03.119',NULL,NULL,NULL,NULL,NULL,'2026-05-12 08:55:35.679'),
(45,'marian.romanienko@gmail.com','+48 733 344 954','$2b$10$BCldS6xh6Pax8FEyegWgOeV0FcT7A86V2406/JO3N/ynqLUJQ8VXq','Mariano Italiano','/uploads/avatars/45-1778608586687.jpg','Metrohouse',NULL,'AGENT','NONE',0,NULL,1,NULL,NULL,'2026-05-12 16:25:23.868','2026-05-12 17:56:26.691',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-12 16:57:11.743',NULL,NULL,NULL,NULL,NULL,'2026-05-12 16:48:30.529'),
(46,'rommaniek3@gmail.com','+48888888888','$2b$10$73NfCFsBgNpJFozMSqztN.qfB7wTxE2W6V4SUnxxPs7Bj9u0Xwm4C','Koko Nuts','/uploads/avatars/46-1778671942966.jpg',NULL,NULL,'USER','NONE',0,NULL,1,'9212','2026-05-13 11:25:46.062','2026-05-13 11:15:40.900','2026-05-13 11:57:32.177',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-13 11:57:32.175',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `UserBlock`
--

DROP TABLE IF EXISTS `UserBlock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserBlock` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blockerUserId` int(11) NOT NULL,
  `blockedUserId` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserBlock_pair_key` (`blockerUserId`,`blockedUserId`),
  KEY `UserBlock_blocker_idx` (`blockerUserId`),
  KEY `UserBlock_blocked_idx` (`blockedUserId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserBlock`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `UserBlock` WRITE;
/*!40000 ALTER TABLE `UserBlock` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserBlock` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `UserReport`
--

DROP TABLE IF EXISTS `UserReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserReport` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reporterUserId` int(11) NOT NULL,
  `targetType` varchar(16) NOT NULL,
  `targetUserId` int(11) DEFAULT NULL,
  `targetOfferId` int(11) DEFAULT NULL,
  `category` varchar(32) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'PENDING',
  `reviewedBy` int(11) DEFAULT NULL,
  `reviewedAt` datetime(3) DEFAULT NULL,
  `reviewerNotes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `UserReport_reporter_idx` (`reporterUserId`),
  KEY `UserReport_targetUser_idx` (`targetUserId`),
  KEY `UserReport_targetOffer_idx` (`targetOfferId`),
  KEY `UserReport_status_idx` (`status`,`createdAt`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserReport`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `UserReport` WRITE;
/*!40000 ALTER TABLE `UserReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserReport` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `VerificationToken`
--

DROP TABLE IF EXISTS `VerificationToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `VerificationToken` (
  `identifier` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `expires` datetime(3) NOT NULL,
  UNIQUE KEY `VerificationToken_token_key` (`token`),
  UNIQUE KEY `VerificationToken_identifier_token_key` (`identifier`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VerificationToken`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `VerificationToken` WRITE;
/*!40000 ALTER TABLE `VerificationToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `VerificationToken` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-14  1:30:28
